# How to apply

Against `discrete_calculus_rust` at commit a69bc45f.

1. `crate/` holds the five changed files in the crate's own layout, whole:
   `src/birthday.rs`, `examples/bake_birthday.rs`, `order_birthday_film.sh`,
   `bundle_birthday.sh`, `player/birthday/index.html`. Copy them over, or apply the
   unified diffs in `patches/` instead (`patch -p0 < patches/birthday.rs.diff` from
   the crate root, one per file).
2. Rebuild the baker, then rebuild the sidecars without rendering to see the new
   `bodies.json`, `loop_closed` and the hold histogram:
   `BIRTHDAY_SIDECAR_ONLY=1 BIRTHDAY_MASTER=square BIRTHDAY_NIGHT=1 bake_birthday <track> <dir> 3840x3840 30 60`
3. Re-render the night pass (it was unfinished anyway). The film can stay as it is;
   its sidecar gains nothing it needs. `facts.json` is unchanged.
4. Bundle with the two new optional arguments: dedication (8th) and language (9th),
   or through the order script with `FILM_LANG=es|fr` and `FILM_DEDICATION`.
5. Open the result on a phone and a tablet and turn them: the one check that could
   not be made from here (see README, "4K, under load").

`tools/` reproduces every number in the README: `predict.py` (the director port),
`harness.mjs` + `analyse.py` (the seams), `ux_check.mjs` (the cards, in `es`, `fr`, `en`),
`make_bodies.py` (a bodies.json from any track), `bundle_check.sh` (the bundler's checks
on one player file).
