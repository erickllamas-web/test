// bake_birthday — render the birth-sky film to finished frames, on the metal.
// ============================================================================
// Erick J. Llamas — Nous Research Centre
//
// The product is a VIDEO. There is nothing to render live: the sky is computed
// once by the daemon, the film is rendered once here, and what the customer
// receives is a finished film plus a small sidecar that keeps it INTERACTIVE —
// they can still tap a star and be told its name, and still type "Orion" and
// have the video go there.
//
// ── WHY PROCESSES, NOT THREADS ──────────────────────────────────────────────
// `sky::render_from_scene` reads process-global state: the Sun-light kill switch
// is a global atomic, and the compiled-scene and star-projection caches are
// SINGLE-SLOT mutexes keyed on the frame's parameters. Two threads rendering two
// different film-seconds would flip each other's kill switch mid-frame and evict
// each other's cache on every single frame — wrong pixels AND slower than one
// thread. So parallelism is by SHARD: N independent processes, each rendering a
// contiguous run of frames. Contiguous matters — within a shard the samples
// advance in order, so the single-slot caches hit the way they were designed to.
//
//   bake_birthday <track.json> <outdir> [WxH] [fps] [anim_secs] [shard/total]
//
// With no shard argument it renders everything in one process. `bake_all.sh`
// spawns one process per core and then muxes.
//
// ── HONESTY CONTRACT ────────────────────────────────────────────────────────
// Every frame is one real celestial-daemon sample, rendered by the same engine
// the interactive page used. The sidecar records, per frame, the exact camera
// and sky state it was rendered with — so the shell's hit-test inverts the
// truth, not a reconstruction.

use babel_productions::birthday::{FilmTrack, Light, Phase};
use babel_productions::png;
use babel_productions::sky as bsky;
use babel_productions::star_names::NAMED_STARS;
use std::io::Write as _;

/// Photometric calibration for THIS PRODUCT ONLY.
///
/// The shared renderer's defaults are left exactly where they are — every other
/// thing that draws a sky (the NOUSCON plates, the orrery, the site) keeps the
/// pixels it has always produced. These three knobs are read once by `sky.rs`
/// through its existing `sky_env` seam, so setting them here scopes the change
/// to the birthday film and nothing else.
///
/// WHY, measured rather than guessed. `star_brightness` clips Pogson flux at
/// mag 2.9834, so all 170 stars brighter than that rendered at exactly 1.0 — a
/// 58.8× flux range flattened. With magnitude carrying no information up there,
/// the on-screen order was decided by colour alone, and `star_color`
/// peak-normalises, which charges a star for its colour a second time on top of
/// a V magnitude that already accounts for it. Together they put Sargas (mag
/// 1.86) on screen brighter than Sirius (−1.46), and left Antares (1.06) the
/// dimmest of the fourteen brightest stars — which is exactly what Erick saw.
///
///   SKY_MAG_HEADROOM=60  admits Sirius with nothing clipped (15271/255 = 59.9)
///                        while holding the faint end of the curve fixed.
///   SKY_LUM_NORM=1       colour carries hue, magnitude carries brightness.
///   SKY_HALO_NEBULA=1.8  Antares's reflection halo actually gets wide, instead
///                        of the 0.22/5.00 pair that measured DIMMER than the
///                        default it was supposed to be widening.
///
/// Set before any render call, because `sky.rs` caches each in a `OnceLock`.
fn calibrate_for_this_film() {
    // SKY_PLANET_GLOBES=0 is a DETERMINISM requirement, not a look choice. The lit
    // planet globe is emitted only on a COLD scene build, so with it on, exactly
    // one frame per worker process carries lit planet discs and every restaged
    // frame after it carries points — which makes the film change when the shard
    // count changes. At this FOV a planet is well under a pixel either way, so the
    // globe was never visible in a baked frame; a live zoom still gets it.
    // SKY_NO_COMPASS=1: the E/W horizon marks are drawn by the player as
    // lines instead, so they stay sharp at every screen size and zoom — burned
    // into the frame they are a few pixels of video that any enlargement blurs.
    // SKY_DITHER=1: the sky gradient leaves the renderer through an 8-bit
    // quantiser, and undithered it steps. Measured on the Pai 4K sunset frame
    // (f608, 960² crop at 1:1): 43 blue levels in a 960 px column, bands a
    // median 11 px and up to 79 px wide — a staircase the 10-bit encode then
    // preserves faithfully. The renderer's own TPDF dither (sky.rs, default
    // OFF so every still product stays byte-identical) trades that staircase
    // for sub-LSB noise. Cost is unmeasured here: read it off the shard log's
    // render ms on the next bake.
    for (k, v) in [("SKY_MAG_HEADROOM", "60"), ("SKY_LUM_NORM", "1"),
                   ("SKY_HALO_NEBULA", "1.8"), ("SKY_PLANET_GLOBES", "0"),
                   ("SKY_NO_COMPASS", "1"), ("SKY_DITHER", "1")] {
        if std::env::var_os(k).is_none() {
            // SAFETY: single-threaded, first thing in main, before any render
            // call and therefore before any reader thread exists.
            unsafe { std::env::set_var(k, v); }
        }
    }
}

/// Which layers of the sky the film paints. `BIRTHDAY_SKY`:
///
///   stars     the compiled-in star field only (the first Pai film)
///   milkyway  + the diffuse Milky Way band, dust rift, star clouds and the
///             NGC/IC glows (`toggle_dsos`) — the same star set, so tap-to-name
///             and search are untouched
///   full      + the full 1.65 M-star catalogue, as the still sky prints use
fn sky_layers() -> String {
    let v = std::env::var("BIRTHDAY_SKY").unwrap_or_else(|_| "milkyway".into());
    // "milkyway" is handed to the director (`FilmTrack::milky_way`), which paints
    // it in the night view only — see there. "full" is the still prints' global
    // switch and is not twilight-safe; it is kept for comparison, not the film.
    if v == "full" && !bsky::full_stars_on() { bsky::toggle_full_stars(); }
    v
}

fn main() {
    calibrate_for_this_film();
    let layers = sky_layers();
    let a: Vec<String> = std::env::args().collect();
    let arg = |i: usize, d: &str| a.get(i).cloned().unwrap_or_else(|| d.to_string());

    let track_path = arg(1, "crates/morpheus_web/dist/birthday_track.json");
    let outdir = arg(2, "/tmp/birthday_bake");
    let size = arg(3, "1280x720");
    let fps: f64 = arg(4, "30").parse().unwrap_or(30.0);
    let anim_secs: f64 = arg(5, "0").parse().unwrap_or(0.0);
    let (shard, shards) = {
        let s = arg(6, "1/1");
        let mut it = s.split('/');
        let k: usize = it.next().and_then(|v| v.parse().ok()).unwrap_or(1);
        let n: usize = it.next().and_then(|v| v.parse().ok()).unwrap_or(1);
        (k.max(1).min(n.max(1)), n.max(1))
    };
    let (w, h) = {
        let mut it = size.split(['x', 'X']);
        (it.next().and_then(|v| v.parse::<u32>().ok()).unwrap_or(1280),
         it.next().and_then(|v| v.parse::<u32>().ok()).unwrap_or(720))
    };

    let text = match std::fs::read_to_string(&track_path) {
        Ok(t) => t,
        Err(e) => { eprintln!("cannot read {track_path}: {e}"); std::process::exit(1); }
    };
    let mut film = match FilmTrack::from_text(&text) {
        Ok(f) => f,
        Err(e) => { eprintln!("bad track: {e}"); std::process::exit(2); }
    };
    if anim_secs > 0.0 { film.set_anim_secs(anim_secs); }
    film.milky_way = layers == "milkyway";

    // BIRTHDAY_NIGHT=1 bakes the PLANETARIUM PASS instead of the cinematic film:
    // one act, uniform clock, the Sun's light off in every frame. It is the pass
    // a search seeks into, because it is the only one where every star that ever
    // rises is on screen against a dark sky. Same binary, same director, same
    // track — only the mode differs, so the two films can never drift apart.
    let night = std::env::var("BIRTHDAY_NIGHT").map(|v| v == "1").unwrap_or(false);
    if night { film.set_night_only(true); }

    // BIRTHDAY_MASTER=square renders ONE square frame that holds every screen
    // shape as a centred crop at full resolution: its 16:9 crop is exactly the
    // landscape film, and portrait phone and both tablet shapes are cut from the
    // same pixels. See `FilmTrack::frame_widen` and `screen_shapes`.
    let square = std::env::var("BIRTHDAY_MASTER").map(|v| v == "square").unwrap_or(false);
    if square {
        if w != h { eprintln!("BIRTHDAY_MASTER=square needs a square size, got {w}×{h}"); std::process::exit(1); }
        film.set_frame_widen(16.0 / 9.0);
    }

    let loop_s = film.loop_secs();
    let nframes = (loop_s * fps).round() as usize;
    if let Err(e) = std::fs::create_dir_all(format!("{outdir}/frames")) {
        eprintln!("cannot create {outdir}/frames: {e}"); std::process::exit(1);
    }

    // Shard 1 owns the sidecar — it is the same for every shard, and writing it
    // once avoids N processes racing on one file.
    if shard == 1 {
        write_sidecar(&film, &outdir, w, h, fps, nframes, square);
        // BIRTHDAY_SIDECAR_ONLY=1 — regenerate the JSON companions without
        // re-rendering a single pixel. The sidecar, the seek index, the star
        // table and the stick figures are all pure functions of the track, so
        // adding a column to any of them should cost a second, not the ~6
        // minutes a full pixel bake takes.
        if std::env::var("BIRTHDAY_SIDECAR_ONLY").map(|v| v == "1").unwrap_or(false) {
            return;
        }
    }

    // Work is handed out in CHUNKS that round-robin across shards, not as one
    // contiguous block each.
    //
    // WHY. Measured on the cinematic cut with 6 shards, one contiguous block
    // apiece: 103.5s, 140.6s, 181.9s, 173.3s, 218.9s, 248.0s. The bake ends when
    // the LAST shard ends, so it took 248.0s to do 1066.2s of work that six cores
    // should have finished in 177.7s — a 1.40× penalty paid entirely to layout.
    // The cause is that frame cost is not uniform along the film: the opening is
    // cheap daylight with almost no stars, the tail is the full night field, and
    // contiguous blocks hand one shard the whole expensive end.
    //
    // Round-robin chunks give every shard the same mix of cheap and expensive
    // frames. The chunk is still a contiguous RUN, which is the thing the
    // renderer's single-slot scene and star-projection caches actually need —
    // only the run is now 24 frames instead of a sixth of the film. Long enough
    // to amortise the cache miss at its head, short enough that no shard can
    // inherit the expensive tail on its own.
    const CHUNK: usize = 24;
    let mut mine: Vec<usize> = Vec::new();
    let mut chunk = 0usize;
    while chunk * CHUNK < nframes {
        if chunk % shards == shard - 1 {
            let lo = chunk * CHUNK;
            mine.extend(lo..(lo + CHUNK).min(nframes));
        }
        chunk += 1;
    }
    let total = mine.len();
    eprintln!("shard {shard}/{shards}: {total} frames of {nframes} in {CHUNK}-frame chunks  \
               ({w}×{h} @ {fps} fps, {loop_s:.1}s{}, sky: {layers})",
              if night { ", PLANETARIUM PASS — no sunlight" } else { "" });

    // Three stages, timed apart. The old line reported only the render and then
    // a total, and the gap between them was where the bake was actually going —
    // 520 ms of render inside 880 ms of wall clock. Attributing the cost is the
    // whole point: you cannot fix what you have not separated.
    let t_start = std::time::Instant::now();
    let raw = std::env::var("BIRTHDAY_RAW").map(|v| v == "1").unwrap_or(false);
    let (mut painted, mut t_render, mut t_encode, mut t_write) = (0usize, 0.0f64, 0.0f64, 0.0f64);
    // BIRTHDAY_WINDOW: never render a frame more than this many frames past the
    // encoder's cursor (`frames/.cursor`, written by bake_all.sh's collector).
    // Keeps the raw backlog — 44 MB a frame at 3840² — inside the disk.
    let window: Option<usize> = std::env::var("BIRTHDAY_WINDOW").ok().and_then(|v| v.parse().ok());
    let cursor_path = format!("{outdir}/frames/.cursor");
    for k in mine {
        if let Some(win) = window {
            loop {
                let cur = std::fs::read_to_string(&cursor_path).ok()
                    .and_then(|s| s.trim().parse::<usize>().ok()).unwrap_or(0);
                if k <= cur + win { break; }
                std::thread::sleep(std::time::Duration::from_millis(200));
            }
        }
        let t = k as f64 / fps;

        // Pairs with `SKY_DEBUG_BODIES` in sky.rs: that dump says WHAT was built,
        // this says WHICH FRAME asked for it. Two shards that disagree about a
        // frame can only be compared once both halves are on the same line.
        if std::env::var_os("SKY_DEBUG_BODIES").is_some() {
            let s = film.shot(t);
            eprintln!("[frame] k={k} t={t:.6} phase={:?} sample={} sun_off={:.3}",
                      s.phase, s.sample, s.sun_off_amt);
        }
        let t0 = std::time::Instant::now();
        let rgba = film.frame_rgba(w, h, t);
        let ms = t0.elapsed().as_secs_f64() * 1e3;
        t_render += ms;

        // RGB on disk, not RGBA: the renderer's alpha is 255 everywhere and the
        // muxer throws it away, so the fourth channel would cost a third more
        // bytes per frame to say nothing.
        //
        // BIRTHDAY_RAW=1 skips the PNG entirely and writes those RGB bytes flat.
        // Measured on the cinematic cut, the encode was the LARGEST single item
        // in the bake — `render 186–217 ms · png 229–251 ms` per shard, so 52–57%
        // of every frame went into compressing an image whose only reader is
        // `ffmpeg`, one command later, which decompresses it and deletes it. The
        // deflate is honest work done for nobody.
        //
        // The trade is disk: 1280×720×3 = 2.76 MB a frame, so 1710 frames is
        // ~4.7 GB of intermediate against ~40 MB of PNG. That is why it is a knob
        // and not the default — on the 16 GB tmpfs `/tmp` it is 4.7 GB of RAM.
        // Point `outdir` at real disk when using it.
        let t1 = std::time::Instant::now();
        let (bytes, ext) = if raw {
            let n = w as usize * h as usize;
            let mut rgb = Vec::with_capacity(n * 3);
            for i in 0..n { rgb.extend_from_slice(&rgba[i * 4..i * 4 + 3]); }
            (rgb, "rgb")
        } else {
            (png::encode_rgba_as_rgb(&rgba, w, h), "png")
        };
        t_encode += t1.elapsed().as_secs_f64() * 1e3;

        // WRITE THEN RENAME, never write in place. A frame file must be either
        // absent or complete, never half-written — because `bake_all.sh` no longer
        // waits for the bake to finish before muxing. It runs ffmpeg CONCURRENTLY,
        // fed by a collector that walks frame 0, 1, 2 … and blocks on each until it
        // appears. `std::fs::write` creates the file and then fills it, so a
        // collector could open a 40-byte "frame" and hand ffmpeg garbage. `rename`
        // within one directory is atomic, so the final name appears only once every
        // byte is behind it.
        //
        // This is what lets the mux overlap the render instead of following it, and
        // it is what lets the collector DELETE each frame as it is consumed — which
        // is the difference between 4.5 GB of intermediate and about 50 MB.
        let t2 = std::time::Instant::now();
        let path = format!("{outdir}/frames/f{k:06}.{ext}");
        let tmp = format!("{outdir}/frames/.f{k:06}.{ext}.part");
        if let Err(e) = std::fs::write(&tmp, &bytes) {
            eprintln!("write {tmp}: {e}"); std::process::exit(3);
        }
        if let Err(e) = std::fs::rename(&tmp, &path) {
            eprintln!("rename {tmp} -> {path}: {e}"); std::process::exit(3);
        }
        t_write += t2.elapsed().as_secs_f64() * 1e3;

        painted += 1;
        if painted % 25 == 0 || painted == total {
            let done = painted as f64;
            let el = t_start.elapsed().as_secs_f64();
            let eta = el / done * (total as f64 - done);
            eprintln!("  shard {shard}: {painted}/{total} frames  last {ms:.0} ms  \
                       mean {:.0} ms  eta {:.0}s", el / done * 1e3, eta);
        }
    }
    let el = t_start.elapsed().as_secs_f64();
    let d = painted.max(1) as f64;
    eprintln!("shard {shard}/{shards} done: {painted} frames in {el:.1}s = {:.0} ms/frame",
              if painted > 0 { el / painted as f64 * 1e3 } else { 0.0 });
    eprintln!("shard {shard}/{shards} split: render {:.0} ms · png {:.0} ms · write {:.0} ms \
               ({:.0}% of the frame is not rendering)",
              t_render / d, t_encode / d, t_write / d,
              100.0 * (t_encode + t_write) / (t_render + t_encode + t_write).max(1e-9));
}

/// The screens the film is cut for. A plain bake is its own single shape; a
/// square master yields four centred crops, each at the master's full detail:
/// landscape 16:9, phone portrait 9:16, tablet 4:3 and 3:4. Sides are kept even,
/// which the video encoder requires.
fn screen_shapes(w: u32, h: u32, square: bool) -> Vec<(&'static str, u32, u32)> {
    screen_cuts(w, h, square).into_iter().map(|(n, cw, ch, _, _)| (n, cw, ch)).collect()
}

/// Each shape as (name, crop w, crop h, encoded w, encoded h). The tablet crops
/// of a 3840 master are 3840×2880 — more pixels than the largest frame phone
/// and tablet hardware decoders are specified for — so they are encoded at
/// three quarters: 2880×2160, still above an iPad Pro's 2732×2048 screen.
/// Shrinking only ever sharpens; nothing is ever enlarged.
fn screen_cuts(w: u32, h: u32, square: bool) -> Vec<(&'static str, u32, u32, u32, u32)> {
    if !square { return vec![("", w, h, w, h)]; }
    let even = |v: u32| v & !1;
    let s = w;
    let (a, b) = (even(s * 9 / 16), even(s * 3 / 4));
    let t = |v: u32| if s > 2880 { even(v * 3 / 4) } else { v };
    vec![("169", s, a, s, a), ("916", a, s, a, s),
         ("43", s, b, t(s), t(b)), ("34", b, s, t(b), t(s))]
}

/// The sidecar is what keeps a finished video INTERACTIVE. Two parts:
///
///   `film.json`  — per-frame camera + sky state. The shell reads the frame
///                  index from the video's current time and gets the exact
///                  camera that frame was rendered with, so a tap inverts the
///                  truth rather than a guess.
///   `seek.json`  — every constellation and named star mapped to the film-second
///                  at which it is best placed, so typing a name is a seek.
fn write_sidecar(film: &FilmTrack, outdir: &str, w: u32, h: u32, fps: f64, nframes: usize,
                 square: bool) {
    let path = format!("{outdir}/film.json");
    let mut f = match std::fs::File::create(&path) {
        Ok(f) => f, Err(e) => { eprintln!("cannot create {path}: {e}"); return; } };

    let night = film.warp.share(Light::Night);
    let twi = film.warp.share(Light::Twilight);
    let mut s = String::new();
    s.push_str(&format!(
        "{{\"w\":{w},\"h\":{h},\"fps\":{fps},\"frames\":{nframes},\
         \"loop_secs\":{:.4},\"intro_secs\":{:.4},\"hero_secs\":{:.4},\"anim_secs\":{:.4},\
         \"lat\":{:.6},\"lon\":{:.6},\"samples\":{},\
         \"night_share\":{night:.4},\"twilight_share\":{twi:.4},\"day_share\":{:.4},\n",
        film.loop_secs(), film.intro_secs, film.hero_secs, film.anim_secs,
        film.lat(), film.lon(), film.n, film.warp.share(Light::Day)));
    // Whether this cut's last frame runs on into its first. The planetarium
    // pass over one sidereal day does (`FilmTrack::night_last`); the cinematic
    // cut, which ends the next morning and restarts at the birth hour, never
    // does. The player reads this: a cut that is not closed is taken through
    // a short dip to black at the loop point, a closed one is left alone.
    s.push_str(&format!("\"loop_closed\":{},\"loop_lst_residual_deg\":{:.3},\n",
                        film.loop_closed(), film.loop_lst_residual_deg()));

    // The screen shapes cut from a square master. `scale` is crop height over
    // master height: a centred crop is the SAME camera with its vertical
    // half-field tangent multiplied by it, which is all the player needs to
    // project a star into any of them exactly.
    if square {
        // `w`/`h` are the ENCODED size the player lays out; `cw`/`ch` the crop
        // taken from the master, which the encoder reads.
        let parts: Vec<String> = screen_cuts(w, h, true).iter()
            .map(|(n, cw, ch, ow, oh)| format!(
                "\"{n}\":{{\"w\":{ow},\"h\":{oh},\"cw\":{cw},\"ch\":{ch},\"scale\":{:.6}}}",
                *ch as f64 / h as f64))
            .collect();
        s.push_str(&format!("\"shapes\":{{{}}},\n", parts.join(",")));
    }

    // Per-frame director state. Compact: one array per field, so the browser
    // reads it as columns and never allocates 1,710 little objects.
    let mut az = String::from("\"aim_az\":[");
    let mut alt = String::from("\"aim_alt\":[");
    let mut fov = String::from("\"fov\":[");
    let mut smp = String::from("\"sample\":[");
    let mut lst = String::from("\"lst\":[");
    let mut sun = String::from("\"sun_alt\":[");
    // The faintest magnitude this frame actually PAINTED. Without it the player
    // would have to guess the cutoff, and would confidently name a mag-9 star
    // that is nowhere on the screen. With it, a tap can only ever return
    // something the customer can genuinely see.
    let mut mlim = String::from("\"maglim\":[");
    for k in 0..nframes {
        let sh = film.shot(k as f64 / fps);
        let c = if k > 0 { "," } else { "" };
        az.push_str(&format!("{c}{:.3}", sh.aim_az.rem_euclid(360.0)));
        alt.push_str(&format!("{c}{:.3}", sh.aim_alt));
        fov.push_str(&format!("{c}{:.2}", sh.fov_deg));
        smp.push_str(&format!("{c}{}", sh.sample));
        lst.push_str(&format!("{c}{:.3}", film.lst(sh.sample)));
        sun.push_str(&format!("{c}{:.3}", film.sun_alt(sh.sample)));
        let sc = film.scene_at(sh.sample);
        mlim.push_str(&format!("{c}{:.3}", bsky::scene_star_maglim(&sc, sh.sun_off())));
    }
    for part in [az, alt, fov, smp, lst, sun, mlim] {
        s.push_str(&part); s.push_str("],\n");
    }
    s.truncate(s.trim_end().trim_end_matches(',').len());
    s.push_str("}\n");
    if let Err(e) = f.write_all(s.as_bytes()) { eprintln!("write {path}: {e}"); return; }
    eprintln!("sidecar {path}  ({} KB, {nframes} frames)", s.len() / 1024);

    // The seek index — built for THIS frame shape, because "inside the frame"
    // depends on the aspect ratio. A square master gets one index per screen
    // shape cut from it.
    let steps = (film.anim_secs * fps) as usize;
    for (k, (name, cw, ch)) in screen_shapes(w, h, square).into_iter().enumerate() {
        let t0 = std::time::Instant::now();
        let idx = film.build_seek_index_crop(w, h, cw, ch, steps);
        let ms = t0.elapsed().as_secs_f64() * 1e3;
        let mut body = String::from("[");
        for (i, e) in idx.iter().enumerate() {
            if i > 0 { body.push(','); }
            body.push_str(&e.to_json());
        }
        body.push_str("]\n");
        // The first shape is also `seek.json` — the landscape index every
        // existing check and the hosted player already read.
        let mut paths = Vec::new();
        if k == 0 { paths.push(format!("{outdir}/seek.json")); }
        if !name.is_empty() { paths.push(format!("{outdir}/seek_{name}.json")); }
        for spath in paths {
            match std::fs::write(&spath, body.as_bytes()) {
                Ok(()) => {
                    let framed = idx.iter().filter(|e| e.framed).count();
                    eprintln!("seek index {spath}  {cw}×{ch}  {} entries, {framed} seekable ({:.0}%), \
                               built in {ms:.0} ms",
                              idx.len(), framed as f64 / idx.len() as f64 * 100.0);
                }
                Err(e) => eprintln!("write {spath}: {e}"),
            }
        }
    }

    write_sky_table(outdir);
    write_figures(outdir);
    write_bodies(film, outdir);

    // A one-line honest description of what this bake IS.
    let acts = [(Phase::Intro, film.intro_secs), (Phase::Hero, film.hero_secs),
                (Phase::Anim, film.anim_secs)];
    eprintln!("film: {} acts — intro {:.0}s, hero {:.0}s, animation {:.0}s; \
               animation is {:.0}% night + {:.0}% twilight",
              acts.len(), film.intro_secs, film.hero_secs, film.anim_secs,
              night * 100.0, twi * 100.0);
}

/// The Sun, the Moon and the planets at every sample of the track, plus the
/// track's clock — `bodies.json`. Three things in the player read it:
///
///   · the tap, so the Moon and the planets can be named under a finger (they
///     are not catalogue stars and were untappable before);
///   · the clock, which shows the sky's local time instead of film seconds;
///   · the card's line about where a thing stood at the birth instant.
///
/// HONESTY CONTRACT: every position is the daemon's own sample, copied, not
/// computed. Columnar like `sky.json`. About 190 KB at 720 samples, ~1.1 MB at
/// 4320; it is read once at boot.
fn write_bodies(film: &FilmTrack, outdir: &str) {
    let n = film.n;
    let mut s = String::with_capacity(256 * 1024);
    s.push_str(&format!(
        "{{\"n\":{n},\"date\":\"{}\",\"utc_off_h\":{},\"t0_h\":{},\"span_h\":{:.6},\
         \"lat\":{:.6},\"lon\":{:.6},\n",
        esc(&film.date), film.utc_off_h, film.birth_local_h, film.cycle_h, film.lat(), film.lon()));
    s.push_str("\"names\":[");
    for (i, nm) in film.names.iter().enumerate() {
        if i > 0 { s.push(','); }
        s.push_str(&format!("\"{}\"", esc(nm)));
    }
    s.push_str("],\n");
    // one column per field, over the samples (the scene is rebuilt per field;
    // at 4320 samples that is a few tens of milliseconds, once per bake)
    let scenes: Vec<_> = (0..n).map(|si| film.scene_at(si)).collect();
    let col = |name: &str, f: &dyn Fn(usize) -> String| {
        let mut c = format!("\"{name}\":[");
        for si in 0..n {
            if si > 0 { c.push(','); }
            c.push_str(&f(si));
        }
        c.push_str("],\n");
        c
    };
    s.push_str(&col("lst",        &|i| format!("{:.3}", scenes[i].lst_deg)));
    s.push_str(&col("sun_az",     &|i| format!("{:.3}", scenes[i].sun.az)));
    s.push_str(&col("sun_alt",    &|i| format!("{:.3}", scenes[i].sun.alt)));
    s.push_str(&col("moon_az",    &|i| format!("{:.3}", scenes[i].moon.az)));
    s.push_str(&col("moon_alt",   &|i| format!("{:.3}", scenes[i].moon.alt)));
    s.push_str(&col("moon_ang",   &|i| format!("{:.4}", scenes[i].moon.ang_size_deg)));
    s.push_str(&col("moon_illum", &|i| format!("{:.4}", scenes[i].moon.illum_fraction)));
    s.push_str(&col("moon_wax",   &|i| if scenes[i].moon.waxing { "1".into() } else { "0".into() }));
    for (key, pick) in [("pl_az", 0), ("pl_alt", 1), ("pl_mag", 2), ("pl_ang", 3)] {
        s.push_str(&format!("\"{key}\":["));
        for k in 0..film.names.len() {
            if k > 0 { s.push(','); }
            s.push('[');
            for si in 0..n {
                if si > 0 { s.push(','); }
                let p = &scenes[si].planets[k];
                s.push_str(&match pick { 0 => format!("{:.3}", p.az), 1 => format!("{:.3}", p.alt),
                                         2 => format!("{:.2}", p.mag), _ => format!("{:.4}", p.ang_size_deg) });
            }
            s.push(']');
        }
        s.push_str("],\n");
    }
    s.truncate(s.trim_end().trim_end_matches(',').len());
    s.push_str("}\n");
    let path = format!("{outdir}/bodies.json");
    match std::fs::write(&path, s.as_bytes()) {
        Ok(()) => eprintln!("bodies {path}  {n} samples, {} bodies, {} KB", 2 + film.names.len(), s.len() / 1024),
        Err(e) => eprintln!("write {path}: {e}"),
    }
}

/// The Rey stick figures, resolved to sky coordinates for the player.
///
/// `rey_lines::segments()` already holds H.A. Rey's classical figures as pairs of
/// Hipparcos numbers — the drawings that actually look like a hunter and a bull,
/// not the IAU's minimalist dot-joining. The renderer can paint them (`USE_REY=1`
/// in `sky.rs`), but painting them INTO the film would burn them into every
/// frame, and Erick wants a click to make them vanish. So they ship as data: each
/// segment's two endpoints resolved once here through `stars_bin::hip_index()`,
/// and the player draws them on the overlay canvas with the same projection it
/// already uses for the reticle.
///
/// Grouped by constellation, because a figure is only ever drawn one at a time.
/// Coordinates are J2000 RA/dec, matching `sky.json` — the player turns them into
/// pixels with the per-frame `lst`, so the figure tracks the sky as the film runs.
fn write_figures(outdir: &str) {
    let segs = babel_productions::rey_lines::segments();
    let hip = babel_productions::stars_bin::hip_index();
    if segs.is_empty() || hip.is_empty() {
        eprintln!("figures: no Rey segments ({}) or no HIP index ({}) — skipped",
                  segs.len(), hip.len());
        return;
    }

    // con code → flat [ra1,dec1,ra2,dec2, ...]. A segment whose endpoint is not
    // in the catalogue is DROPPED, not guessed: a stick figure with an invented
    // vertex would be a drawing, not a star chart.
    let mut order: Vec<String> = Vec::new();
    let mut lines: Vec<Vec<f32>> = Vec::new();
    let mut dropped = 0usize;
    for s in segs {
        let (a, b) = match (hip.get(&s.hip_a), hip.get(&s.hip_b)) {
            (Some(a), Some(b)) => (*a, *b),
            _ => { dropped += 1; continue }
        };
        let code = String::from_utf8_lossy(&s.con)
            .trim_end_matches('\0').to_string();
        let i = match order.iter().position(|c| *c == code) {
            Some(i) => i,
            None => { order.push(code); lines.push(Vec::new()); order.len() - 1 }
        };
        lines[i].extend_from_slice(&[a.0, a.1, b.0, b.1]);
    }

    let mut s = String::with_capacity(128 * 1024);
    s.push_str("{\"epoch\":\"J2000\",\"source\":\"H.A. Rey via Dominic Ford\",\"con\":{");
    for (i, code) in order.iter().enumerate() {
        if i > 0 { s.push(','); }
        s.push_str(&format!("\"{}\":[", esc(code)));
        for (j, v) in lines[i].iter().enumerate() {
            if j > 0 { s.push(','); }
            s.push_str(&format!("{:.4}", v));
        }
        s.push(']');
    }
    s.push_str("}}\n");

    let path = format!("{outdir}/figures.json");
    let total: usize = lines.iter().map(|l| l.len() / 4).sum();
    match std::fs::write(&path, s.as_bytes()) {
        Ok(()) => eprintln!("figures {path}  {} constellations, {total} segments, \
                             {dropped} dropped (endpoint not in catalogue), {} KB",
                            order.len(), s.len() / 1024),
        Err(e) => eprintln!("write {path}: {e}"),
    }
}

/// The named-star table, written out so the PLAYER needs no renderer.
///
/// This is what makes the shipped thing a self-contained video rather than a
/// 10 MB wasm download. Given `sky.json` plus the per-frame `lst` in
/// `film.json`, a few lines of JavaScript can turn any star's J2000 RA/dec into
/// the exact pixel it occupies in the frame on screen — which is all a tap or a
/// reticle ever needs. The heavy renderer stays where it belongs: at bake time.
///
/// Columnar on purpose. 3,212 stars as one object each is ~3,212 allocations
/// and a lot of repeated key text; as seven parallel arrays it is a handful.
fn write_sky_table(outdir: &str) {
    // Constellations repeat ~36× each, so store the 88 codes once and index
    // into them rather than writing "CMa" three thousand times.
    let mut cons: Vec<&'static str> = Vec::new();
    let mut ci: Vec<usize> = Vec::with_capacity(NAMED_STARS.len());
    for s in NAMED_STARS {
        let i = match cons.iter().position(|c| *c == s.con) {
            Some(i) => i,
            None => { cons.push(s.con); cons.len() - 1 }
        };
        ci.push(i);
    }

    let mut s = String::with_capacity(256 * 1024);
    s.push_str(&format!("{{\"n\":{},\"epoch\":\"J2000\",\n", NAMED_STARS.len()));

    s.push_str("\"con_list\":[");
    for (i, c) in cons.iter().enumerate() {
        if i > 0 { s.push(','); }
        s.push_str(&format!("\"{c}\""));
    }
    s.push_str("],\n");

    // RA/dec to 4 decimals is 0.36 arc-seconds — far finer than the ~0.3°
    // agreement the projection itself has with the daemon, so it costs nothing
    // in truth and saves a third of the file.
    let mut ra = String::from("\"ra\":[");
    let mut dec = String::from("\"dec\":[");
    let mut mag = String::from("\"mag\":[");
    let mut hip = String::from("\"hip\":[");
    let mut con = String::from("\"con\":[");
    let mut nm = String::from("\"name\":[");
    let mut bf = String::from("\"bf\":[");
    for (i, st) in NAMED_STARS.iter().enumerate() {
        let c = if i > 0 { "," } else { "" };
        ra.push_str(&format!("{c}{:.4}", st.ra));
        dec.push_str(&format!("{c}{:.4}", st.dec));
        mag.push_str(&format!("{c}{:.2}", st.mag));
        hip.push_str(&format!("{c}{}", st.hip));
        con.push_str(&format!("{c}{}", ci[i]));
        nm.push_str(&format!("{c}\"{}\"", esc(st.proper)));
        bf.push_str(&format!("{c}\"{}\"", esc(st.bf)));
    }
    for part in [ra, dec, mag, hip, con, nm, bf] {
        s.push_str(&part); s.push_str("],\n");
    }
    s.truncate(s.trim_end().trim_end_matches(',').len());
    s.push_str("}\n");

    let path = format!("{outdir}/sky.json");
    match std::fs::write(&path, s.as_bytes()) {
        Ok(()) => eprintln!("sky table {path}  {} stars, {} constellations, {} KB",
                            NAMED_STARS.len(), cons.len(), s.len() / 1024),
        Err(e) => eprintln!("write {path}: {e}"),
    }
}

/// Escape the two characters that can break a JSON string. Star names are
/// catalogue text, not user input, but a lone backslash in a designation would
/// silently corrupt the whole file, so we do not assume.
fn esc(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"")
}
