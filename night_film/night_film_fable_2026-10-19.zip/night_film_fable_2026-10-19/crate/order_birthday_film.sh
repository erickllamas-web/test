#!/usr/bin/env bash
# order_birthday_film.sh — one order in, one finished film out.
# =============================================================================
# Erick J. Llamas — Nous Research Centre
#
# Chains the pieces that already exist, in order, with nothing typed by hand:
#
#   nemo NEMO_NAME        the place → its coordinates
#   nemo NEMO_TZ_HISTORY  the UTC offset in force at that place on that date
#   sky_track_bake        the daemon's positions track for that instant
#   bake_all.sh ×2        the film and the night cut, square master, every shape
#   facts_birthday.sh     the tables
#   bundle_birthday.sh    every check, then the installable site
#
#   order_birthday_film.sh "<place>" <YYYY-MM-DD> <HH:MM> <out_dir> [size]
#
# e.g. order_birthday_film.sh "Pai" 2026-09-04 10:00 ~/films/pai_20260904
#
# The caption is the place as the customer wrote it and the date as they gave
# it; the coordinates it is checked against are nemo's, the same ones the film
# is rendered for.

set -u
place="${1:?place, as the customer wrote it}"; date="${2:?YYYY-MM-DD}"
clock="${3:?local time HH:MM}"; out="${4:?output dir}"; size="${5:-3840x3840}"
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
root="$(cd "$here/../.." && pwd)"

nemo() { printf '%s\n' "$1" | timeout 15 nc -U /tmp/nemo.sock -q 2; }
[ -S /tmp/nemo.sock ] || { echo "nemo daemon down (/tmp/nemo.sock)" >&2; exit 2; }
[ -S /tmp/celestial.sock ] || { echo "celestial daemon down (/tmp/celestial.sock)" >&2; exit 2; }

# ── where ────────────────────────────────────────────────────────────────────
hit=$(nemo "NEMO_NAME $place")
mla=$(printf '%s' "$hit" | grep -o '"micro_lat":-\?[0-9]*' | cut -d: -f2)
mlo=$(printf '%s' "$hit" | grep -o '"micro_lon":-\?[0-9]*' | cut -d: -f2)
[ -n "$mla" ] && [ -n "$mlo" ] || { echo "nemo does not know the place \"$place\": $hit" >&2; exit 1; }
lat=$(awk -v v="$mla" 'BEGIN{ printf "%.6f", v / 1e6 }')
lon=$(awk -v v="$mlo" 'BEGIN{ printf "%.6f", v / 1e6 }')

# ── when, in UTC ─────────────────────────────────────────────────────────────
# The offset depends on the instant and the instant on the offset, so ask
# twice: once at the clock time read as UTC, once at the instant that gives.
# Twice settles it everywhere except inside a DST changeover hour.
wall=$(date -u -d "$date $clock" +%s) || { echo "bad date/time: $date $clock" >&2; exit 1; }
off=0
for pass in 1 2; do
  tzr=$(nemo "NEMO_TZ_HISTORY $mla $mlo $((wall - off))")
  off=$(printf '%s' "$tzr" | grep -o '"utc_offset_seconds":-\?[0-9]*' | cut -d: -f2)
  [ -n "$off" ] || { echo "nemo gave no time zone for $lat,$lon: $tzr" >&2; exit 1; }
done
# Settled only if the offset at the instant it implies is the same offset. On
# the night the clocks jump forward, a clock time inside the jump never happens
# at that place — refuse it rather than pick an instant the customer never had.
chk=$(nemo "NEMO_TZ_HISTORY $mla $mlo $((wall - off))" | grep -o '"utc_offset_seconds":-\?[0-9]*' | cut -d: -f2)
[ "$chk" = "$off" ] || {
  echo "$clock on $date never happened in $place — the clocks changed that night ($off vs $chk s)" >&2
  exit 1; }
tzid=$(printf '%s' "$tzr" | grep -o '"tzid":"[^"]*"' | cut -d'"' -f4)
offh=$(awk -v s="$off" 'BEGIN{ printf "%.6f", s / 3600 }')
hour=$(awk -v c="$clock" 'BEGIN{ split(c, a, ":"); printf "%.6f", a[1] + a[2] / 60 }')

# FILM_LANG=en|es|fr (default en): the language of the player's words and of
# the month in the caption. The month is spelled by `date` under that
# language's locale when the box has it; where it does not, `date` falls back
# to English, so the caption is checked against the language's own month
# names and the order refuses rather than ship "4 SEPTEMBER" on a Spanish film.
# FILM_DEDICATION (optional): a third caption line, e.g. "Para Jane".
film_lang="${FILM_LANG:-en}"
case "$film_lang" in en|es|fr) ;; *) echo "FILM_LANG must be en, es or fr" >&2; exit 1;; esac
case "$film_lang" in es) loc=es_ES.UTF-8;; fr) loc=fr_FR.UTF-8;; *) loc=C;; esac
month=$(LC_ALL=$loc date -u -d "$date" +'%B' 2>/dev/null || date -u -d "$date" +'%B')
case "$film_lang:$month" in
  es:enero|es:febrero|es:marzo|es:abril|es:mayo|es:junio|es:julio|es:agosto|es:septiembre|es:octubre|es:noviembre|es:diciembre) ;;
  fr:janvier|fr:février|fr:mars|fr:avril|fr:mai|fr:juin|fr:juillet|fr:août|fr:septembre|fr:octobre|fr:novembre|fr:décembre) ;;
  en:*) ;;
  *) echo "the $film_lang locale is not installed here ($loc): the caption month came out as '$month'" >&2; exit 1;;
esac
caption_place=$(printf '%s' "$place" | tr '[:lower:]' '[:upper:]')
day_no=$(date -u -d "$date" +'%-d'); year_no=$(date -u -d "$date" +'%Y')
case "$film_lang" in
  es) caption_date="$day_no DE ${month^^} DE $year_no · $clock" ;;
  *)  caption_date="$day_no ${month^^} $year_no · $clock" ;;
esac
echo "order: $place → $lat, $lon ($tzid, UTC$( [ "$off" -ge 0 ] && echo + )$offh h) · $date $clock"
echo "caption: $caption_place / $caption_date"
# ORDER_DRY=1 stops here: resolve the order and show the caption, bake nothing.
[ "${ORDER_DRY:-0}" = 1 ] && exit 0

mkdir -p "$out" || exit 1
cd "$root" || exit 1
[ -x target/release/examples/sky_track_bake ] || cargo build --release -q -p morpheus --example sky_track_bake || exit 1

# ── the track, the two cuts, the tables, the bundle ─────────────────────────
# 4320 samples, not 720. A frame shows one real sample and never an
# interpolation (birthday.rs, HONESTY CONTRACT), so the sky can only move when
# the track has a new sample to show. At 720 samples (one per 2.09 min) the
# clock dwells on twilight so long that the same sample was held for 6 frames
# at a stretch (measured off the shipped film.json: 59% of the animation's
# frame-to-frame transitions showed no sky motion at all, and the planetarium
# pass held each sample 2–3 frames). The sky stepped 0.52° — 5.7 px at the 4K
# centre, one full Sun diameter at sunset — every fifth or sixth frame inside
# a camera move that was smooth. 4320 samples (one per 21 s) give the film one
# sample per frame everywhere but two transitions, and the night pass a fresh
# sample every frame. Predicted with the director ported to test_tools/predict.py,
# which reproduces the shipped sidecars frame for frame. The sidecars do not
# grow (they are per frame); the track file does, ~6×.
target/release/examples/sky_track_bake "$out/track.json" "$date" "$lat" "$lon" "$offh" 4320 5.5 "$hour" 40 \
  || { echo "track bake failed" >&2; exit 1; }
export BIRTHDAY_MASTER=square BIRTHDAY_CODEC="${BIRTHDAY_CODEC:-hevc10,h264}"
nice -n 19 bash "$here/bake_all.sh" "$out/track.json" "$out/film" "$size" 30 0 || exit 1
nice -n 19 bash "$here/facts_birthday.sh" "$date" "$hour" "$lat" "$lon" "$out/film/facts.json" || exit 1
BIRTHDAY_NIGHT=1 nice -n 19 bash "$here/bake_all.sh" "$out/track.json" "$out/night" "$size" 30 60 || exit 1
bash "$here/bundle_birthday.sh" "$out/film" "$out/night" "$out/deliver" \
  "$caption_place" "$caption_date" "$lat" "$lon" "${FILM_DEDICATION:-}" "$film_lang" || exit 1
echo "order done → $out/deliver/site"
