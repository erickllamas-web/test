#!/usr/bin/env bash
# bundle_birthday.sh — assemble the DELIVERABLE from two bakes.
# =============================================================================
# Erick J. Llamas — Nous Research Centre
#
# `bake_all.sh` produces a cut. A cut is not the product. The product is the
# planetarium: two videos, five sidecars and the player that binds them, so the
# customer can type "Antares" and the film goes there. Shipping `film.mp4` on
# its own ships about a third of what was bought.
#
# It takes TWO bakes of the SAME track:
#
#   <film_dir>   BIRTHDAY_NIGHT unset — the cinematic cut, ground and sunlight
#   <night_dir>  BIRTHDAY_NIGHT=1    — the planetarium pass, no sun, no ground,
#                                      uniform clock. This is the cut the SEARCH
#                                      seeks into, because it is the only one in
#                                      which every star is above a dark sky.
#
# and emits both forms a client can actually receive:
#
#   <out>/site/       the hosted form — index.html + siblings, for a URL
#   <out>/offline/    the same film as ONE self-contained .html + the videos,
#                     to be zipped and handed over. `fetch()` is refused on
#                     `file://`, so the sidecars are inlined as `window.EMBED`
#                     rather than fetched. Videos stay separate files: a <video>
#                     src IS allowed on file://, and base64 would inflate 25 MB
#                     to 34 MB for nothing.
#
#   bundle_birthday.sh <film_dir> <night_dir> <out_dir> <PLACE> <DATE LINE> <lat> <lon>
#
# e.g. bundle_birthday.sh ~/bake_pai ~/bake_pai_night ~/deliver_pai \
#        "PAI, THAILAND" "4 SEPTEMBER 2026 · 10:00" 19.3597 98.4408
#
# ── WHY THE CAPTION IS AN ARGUMENT, AND WHY IT IS CHECKED ────────────────────
# The player ships with one customer's caption baked into its markup. Copy it
# unchanged and every film ever sold says MEXICO CITY / 2 APRIL 1983 over some
# other person's sky — a mistake nothing in the pipeline would catch, because
# every pixel would still be correct. So the caption is stamped here, and the
# coordinates it claims are compared against the `lat`/`lon` the renderer
# actually used, which `film.json` records. A caption that disagrees with the
# film it labels is refused rather than shipped.

set -u

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
player="$here/player/birthday/index.html"

film="${1:?usage: bundle_birthday.sh <film_dir> <night_dir> <out_dir> <PLACE> <DATE> <lat> <lon>}"
night="${2:?need the night bake dir}"
out="${3:?need an out dir}"
place="${4:?need the place name for the caption, e.g. \"PAI, THAILAND\"}"
when="${5:?need the date line, e.g. \"4 SEPTEMBER 2026 · 10:00\"}"
lat="${6:?need the latitude the film was rendered for}"
lon="${7:?need the longitude the film was rendered for}"
# Optional: a dedication, set into the caption under the place and date
# ("For Jane, who was born under this sky"). Empty means no third line.
dedication="${8:-}"
# Optional: the language of the player's words — en, es or fr. Stamped on
# <html data-lang>; the player otherwise follows the device's language, and
# `?lang=` in the link overrides both. The caption is stamped as given.
lang="${9:-}"
case "$lang" in ""|en|es|fr) ;; *) echo "unknown language '$lang' (en|es|fr)" >&2; exit 1;; esac
title="$place — $when"

[ -r "$player" ] || { echo "no player at $player" >&2; exit 1; }

# ── the manifest is a CONTRACT, not a wish ───────────────────────────────────
# Every file the player names in its boot must exist before anything is called
# a bundle. A missing sidecar does not fail loudly in a browser — the page opens
# black and the search silently returns nothing, which is exactly the way to
# ship a broken product without noticing.
#
# Note which side each file is required on. `seek.json` is listed under the
# NIGHT bake, not the film one, because that is the cut the player seeks — see
# the copy step below for the full reason.
for f in film.json sky.json figures.json; do
  [ -r "$film/$f" ] || { echo "missing $film/$f" >&2; exit 1; }
done
[ -r "$night/film.json" ]|| { echo "missing $night/film.json (the night bake)" >&2; exit 1; }
[ -r "$night/seek.json" ]|| { echo "missing $night/seek.json (the night bake)" >&2; exit 1; }

# A square master ships one cut per screen shape; a plain bake ships one cut.
# Both bakes must carry the SAME shapes, or a rotated phone would swap to a
# film that does not exist.
shape_keys() { grep -o '"shapes":{.*}},' "$1" | grep -o '"[0-9]*":{' | tr -d '":{' | tr '\n' ' '; }
keys=$(shape_keys "$film/film.json")
[ "$keys" = "$(shape_keys "$night/film.json")" ] || {
  echo "the two bakes carry different screen shapes: film [$keys] night [$(shape_keys "$night/film.json")]" >&2
  exit 1; }
if [ -n "$keys" ]; then
  # Encodings: a bake with a codec list names its cuts film_<shape>.<codec>.mp4.
  # Both bakes must carry the same set, for every shape.
  k1=${keys%% *}
  codecs=$(ls "$film"/film_"$k1".*.mp4 2>/dev/null | sed 's|.*/film_[0-9]*\.\(.*\)\.mp4|\1|' | sort | tr '\n' ' ')
  ncodecs=$(ls "$night"/film_"$k1".*.mp4 2>/dev/null | sed 's|.*/film_[0-9]*\.\(.*\)\.mp4|\1|' | sort | tr '\n' ' ')
  [ "$codecs" = "$ncodecs" ] || {
    echo "the two bakes carry different encodings: film [$codecs] night [$ncodecs]" >&2; exit 1; }
  names() { if [ -n "$codecs" ]; then for c in $codecs; do echo "$1.$c.mp4"; done; else echo "$1.mp4"; fi; }
  for k in $keys; do
    for f in $(names "film_$k"); do
      [ -r "$film/$f" ]  || { echo "missing $film/$f" >&2; exit 1; }
      [ -r "$night/$f" ] || { echo "missing $night/$f (the night bake)" >&2; exit 1; }
    done
    [ -r "$night/seek_$k.json" ] || { echo "missing $night/seek_$k.json (the night bake)" >&2; exit 1; }
  done
else
  [ -r "$film/film.mp4" ]  || { echo "missing $film/film.mp4" >&2; exit 1; }
  [ -r "$night/film.mp4" ] || { echo "missing $night/film.mp4 (the night bake)" >&2; exit 1; }
fi

# The night bake writes its own `film.*` because it does not know it is the B
# cut. The player asks for `night.*`. Rename on the way in, once, here — rather
# than teaching the baker about a naming convention that only the player cares
# about.
# ── the caption must match the film ──────────────────────────────────────────
# `film.json` carries the lat/lon the renderer was actually given. Compare to
# 3 decimals (~100 m) — enough to catch a wrong city or a swapped sign, loose
# enough not to trip on the track's own rounding.
fj_lat=$(grep -o '"lat":[-0-9.]*' "$film/film.json" | head -1 | cut -d: -f2)
fj_lon=$(grep -o '"lon":[-0-9.]*' "$film/film.json" | head -1 | cut -d: -f2)
mism=$(awk -v a="$fj_lat" -v b="$lat" -v c="$fj_lon" -v d="$lon" \
  'BEGIN{ print ((a-b)^2 > 1e-6 || (c-d)^2 > 1e-6) ? 1 : 0 }')
if [ "$mism" = 1 ]; then
  echo "CAPTION DOES NOT MATCH THE FILM" >&2
  echo "  film.json rendered  lat=$fj_lat  lon=$fj_lon" >&2
  echo "  caption claims      lat=$lat  lon=$lon   ($place)" >&2
  exit 1
fi

# The night cut must be the SAME sky as the film cut, or the search seeks into
# somebody else's stars. Two bakes of one track share a lat/lon; two bakes of
# two tracks do not, and nothing downstream would notice.
nj_lat=$(grep -o '"lat":[-0-9.]*' "$night/film.json" | head -1 | cut -d: -f2)
nj_lon=$(grep -o '"lon":[-0-9.]*' "$night/film.json" | head -1 | cut -d: -f2)
[ "$nj_lat" = "$fj_lat" ] && [ "$nj_lon" = "$fj_lon" ] || {
  echo "the night bake is a DIFFERENT sky: film $fj_lat,$fj_lon vs night $nj_lat,$nj_lon" >&2
  exit 1; }

# ── DOES THE INDEX POINT AT ANYTHING? ────────────────────────────────────────
# The checks above prove the two bakes describe the same place. They do NOT
# prove the seek index belongs to the cut the player seeks — and the first
# bundle that went to a customer failed exactly there, silently.
#
# So verify the claim itself, exactly. Every framed entry says "at second t,
# this object is inside the frame". `film.json` carries the camera of every
# frame (aim az/alt and fov), so each entry is projected through the camera of
# the frame it seeks to — the player's own projection, DTrig step included —
# and must land inside the picture: the whole frame, or for a square master the
# crop that index was built for. The index scores moments on a k·anim/(steps−1)
# clock that can round to the neighbouring video frame, so the frame either side
# is accepted too; that is one frame of camera motion, not a tolerance.
#
# (The first version bounded the angle from the aim by fov/2. fov is the
# VERTICAL field, so on a 16:9 frame that refused objects genuinely in the
# picture at its sides — it passed only while the index chose centred moments.)
#
# It still separates the product from the bug by a mile: an index from the
# wrong cut puts objects 150°+ from where the camera points.
coh_check() {  # <seek.json> <sx> <sy>  → "checked bad worst t name"
awk -v FILM="$night/film.json" -v SEEK="$1" -v SX="$2" -v SY="$3" '
function slurp(p,  l,s){ while ((getline l < p) > 0) s = s l; close(p); return s }
function nums(s,key,arr,  t){
  if (!match(s, "\"" key "\":\\[[^]]*\\]")) return 0
  t = substr(s, RSTART, RLENGTH); sub(/^[^[]*\[/,"",t); sub(/\].*$/,"",t)
  return split(t, arr, ",")
}
function num(s,key){ match(s, "\"" key "\":[-0-9.]+"); return substr(s, RSTART+length(key)+3, RLENGTH-length(key)-3) + 0 }
function tan(x){ return sin(x)/cos(x) }
# worst |normalised coordinate| over the frame bounds for frame f (1-based)
function place(f, az, al,   fa,fe,f0,f1,f2,rn,r0,r2,u0,u1,u2,tq,hf,v0,v1,v2,cz,nx,ny){
  fa = AZ[f]*R; fe = AL[f]*R
  f0 = sin(fa)*cos(fe); f1 = sin(fe); f2 = cos(fa)*cos(fe)
  rn = sqrt(f2*f2 + f0*f0); r0 = f2/rn; r2 = -f0/rn
  u0 = f1*r2; u1 = f2*r0 - f0*r2; u2 = -f1*r0
  tq = int(tan(FV[f]*R*0.25)*1e5 + 0.5)/1e5; hf = 2*tq/(1-tq*tq)
  v0 = sin(az*R)*cos(al*R); v1 = sin(al*R); v2 = cos(az*R)*cos(al*R)
  cz = v0*f0 + v1*f1 + v2*f2
  if (cz <= 1e-4) return 99
  nx = (v0*r0 + v2*r2)/cz/(hf*W/H); ny = (v0*u0 + v1*u1 + v2*u2)/cz/hf
  nx = (nx < 0 ? -nx : nx)/SX; ny = (ny < 0 ? -ny : ny)/SY
  return nx > ny ? nx : ny
}
BEGIN{
  R = 3.14159265358979 / 180; worst = -1
  film = slurp(FILM); seek = slurp(SEEK)
  fps = num(film,"fps"); W = num(film,"w"); H = num(film,"h")
  naz = nums(film,"aim_az",AZ); nums(film,"aim_alt",AL); nums(film,"fov",FV)
  if (!naz || !fps || !W){ print "NOAIM"; exit }
  n = split(seek, E, "},{")
  for (i = 1; i <= n; i++){
    e = E[i]
    if (e !~ /"framed":true/) continue
    t = num(e,"t"); az = num(e,"az"); al = num(e,"alt")
    match(e,/"name":"[^"]*"/); nm = substr(e,RSTART+8,RLENGTH-9)
    f = int(t*fps + 0.5) + 1; best = 99
    for (d = -1; d <= 1; d++){ g = f + d; if (g < 1 || g > naz) continue
      q = place(g, az, al); if (q < best) best = q }
    checked++
    if (best > worst){ worst = best; wn = nm; wt = t }
    if (best > 1.0) bad++
  }
  printf "%d %d %.4f %.3f %s\n", checked, bad+0, worst, wt, wn
}'
}

coh_run() {  # <seek.json> <sx> <sy> <label>
  local checked bad worst wt wname
  read -r checked bad worst wt wname <<< "$(coh_check "$1" "$2" "$3")"
  if [ "$checked" = NOAIM ]; then
    echo "cannot read the camera track from $night/film.json — coherence unverifiable" >&2; exit 1
  fi
  [ "${checked:-0}" -gt 0 ] || { echo "$4: no framed entries to check" >&2; exit 1; }
  if [ "$bad" -gt 0 ]; then
    echo "THE SEEK INDEX DOES NOT MATCH THE CUT IT SEEKS ($4)" >&2
    echo "  $bad of $checked framed entries land outside the picture" >&2
    echo "  worst: $wname at t=$wt s, at ${worst}× the frame edge" >&2
    echo "  (is seek.json from the FILM bake instead of the night bake?)" >&2
    exit 1
  fi
  seek_checked=$checked seek_worst=$worst
}

# A square master carries one index per screen shape; each is checked against
# its own crop. A plain bake has the one index, checked against the whole frame.
if grep -q '"shapes":' "$night/film.json"; then
  S=$(grep -o '"w":[0-9]*' "$night/film.json" | head -1 | cut -d: -f2)
  for shp in $(grep -o '"shapes":{[^}]*}[^}]*}[^}]*}[^}]*}' "$night/film.json" | grep -o '"[0-9]*":{"w":[0-9]*,"h":[0-9]*' | tr -d '"{' | tr ':,' '  ' | awk '{print $1":"$3":"$5}'); do
    IFS=: read -r name cw ch <<< "$shp"
    [ -r "$night/seek_$name.json" ] || { echo "missing $night/seek_$name.json" >&2; exit 1; }
    coh_run "$night/seek_$name.json" "$(awk -v a="$cw" -v s="$S" 'BEGIN{print a/s}')" \
            "$(awk -v a="$ch" -v s="$S" 'BEGIN{print a/s}')" "shape $name"
  done
else
  coh_run "$night/seek.json" 1 1 "whole frame"
fi

# ── IS ANYTHING SENT UNDER THE GROUND? ───────────────────────────────────────
# The night cut draws no ground, so a search can land on a moment when the
# object was below the customer's horizon — and the card then says it was "on
# the far side of the Earth". For an object that never rose that is the truth.
# For one that rose that day it is the wrong moment: the first Pai bundle sent
# 1,507 stars and 43 constellations there. An object that climbed clear of the
# horizon (peak above 5°) must be sent to a moment when it was up.
for sf in "$night"/seek*.json; do
under=$(awk -v SEEK="$sf" '
function slurp(p,  l,s){ while ((getline l < p) > 0) s = s l; close(p); return s }
BEGIN{
  n = split(slurp(SEEK), E, "},{")
  for (i = 1; i <= n; i++){
    e = E[i]
    if (e !~ /"framed":true/) continue
    match(e,/"alt":[-0-9.]+/);     al = substr(e,RSTART+6,RLENGTH-6) + 0
    match(e,/"max_alt":[-0-9.]+/); mx = substr(e,RSTART+10,RLENGTH-10) + 0
    match(e,/"name":"[^"]*"/);     nm = substr(e,RSTART+8,RLENGTH-9)
    if (al < 0.5 && mx > 5){ bad++; if (bad <= 5) ex = ex " " nm "(peak " int(mx) "°)" }
  }
  printf "%d%s\n", bad+0, ex
}')
if [ "${under%% *}" != 0 ]; then
  echo "THE SEARCH SENDS OBJECTS UNDER THE GROUND ($(basename "$sf"))" >&2
  echo "  ${under%% *} objects rose above 5° that day but are indexed below the horizon:" >&2
  echo "  ${under#* }" >&2
  exit 1
fi
done

rm -rf "$out"
mkdir -p "$out/site" "$out/offline" || exit 1

# Stamp the caption. `|` as the sed delimiter because a place name may contain
# a slash; the date line carries a "·", so the file stays UTF-8 either way.
#
# The match is on the element's ID, not its class. Keying on `class="d"` looked
# equivalent and was not: the info card's markup uses the same two classes, so
# the date landed in the card as well and every object in the film introduced
# itself as "4 SEPTEMBER 2026 · 10:00" rather than "Planet" or "The Moon". An ID
# is unique by construction, which is the whole reason it is there.
sed -e "s|<title>[^<]*</title>|<title>$title</title>|" \
    -e "s|\(id=\"capPlace\"[^>]*>\)[^<]*|\1$place|" \
    -e "s|\(id=\"capDate\"[^>]*>\)[^<]*|\1$when|" \
    -e "s|\(id=\"capDed\"[^>]*>\)[^<]*|\1$dedication|" \
    -e "s|<html lang=\"en\">|<html lang=\"${lang:-en}\"${lang:+ data-lang=\"$lang\"}>|" \
    "$player" > "$out/site/index.html"

# Both halves of the caption must have landed in their own node...
grep -q -F "id=\"capPlace\">$place<" "$out/site/index.html" || {
  echo "caption stamp failed — '$place' did not land in #capPlace" >&2; exit 1; }
grep -q -F "id=\"capDate\">$when<" "$out/site/index.html" || {
  echo "caption stamp failed — '$when' did not land in #capDate" >&2; exit 1; }
[ -z "$dedication" ] || grep -q -F "id=\"capDed\">$dedication<" "$out/site/index.html" || {
  echo "caption stamp failed — the dedication did not land in #capDed" >&2; exit 1; }

# ...and NOWHERE ELSE in the body. This is the check that would have caught the
# stamp bleeding into the info card. The title legitimately carries both strings
# (it is built from them), so it is excluded by matching on the div markup: the
# place and date may appear inside a <div ...> exactly once each, in their own
# caption node and in no other element.
for pat in "$place" "$when" ${dedication:+"$dedication"}; do
  n=$(grep -o "<div[^>]*>[^<]*" "$out/site/index.html" | grep -c -F "$pat")
  [ "$n" = 1 ] || {
    echo "caption stamp hit $n <div> nodes with '$pat', expected exactly 1" >&2
    echo "  (has it overwritten something that is not the caption?)" >&2
    grep -n -o "<div[^>]*>[^<]*" "$out/site/index.html" | grep -F "$pat" >&2
    exit 1; }
done
# ── NOTHING OF HOW IT IS MADE LEAVES WITH THE FILM ───────────────────────────
# The player's source explains itself at length — crate names, the daemon, the
# DTrig step, the bake. That is for us. The customer's copy carries none of it:
# HTML comments, CSS comments and JS comments are removed here, then two checks
# make sure the result is still a working page and says nothing it should not.
awk '
  /<script>/ { js = 1 }  /<\/script>/ { js = 0 }
  /<style>/  { css = 1 } /<\/style>/  { css = 0 }
  {
    line = $0
    if (html) { if (line ~ /-->/) { sub(/.*-->/, "", line); html = 0 } else next }
    while (!js && match(line, /<!--/)) {
      pre = substr(line, 1, RSTART - 1); rest = substr(line, RSTART + 4)
      if (match(rest, /-->/)) line = pre substr(rest, RSTART + 3)
      else { line = pre; html = 1; break }
    }
    if (css) {
      if (cc) { if (line ~ /\*\//) { sub(/.*\*\//, "", line); cc = 0 } else next }
      while (match(line, /\/\*/)) {
        pre = substr(line, 1, RSTART - 1); rest = substr(line, RSTART + 2)
        if (match(rest, /\*\//)) line = pre substr(rest, RSTART + 2)
        else { line = pre; cc = 1; break }
      }
    }
    if (js) {
      if (line ~ /^[ \t]*\/\//) next
      sub(/[ \t]+\/\/.*$/, "", line)
    }
    if (line ~ /^[ \t]*$/) { if (blank++) next } else blank = 0
    print line
  }' "$out/site/index.html" > "$out/site/index.stripped" \
  && mv "$out/site/index.stripped" "$out/site/index.html" \
  || { echo "comment strip failed" >&2; exit 1; }

# Still a working script? Extract it and let node parse it.
awk '/<script>/{s=1; next} /<\/script>/{s=0} s' "$out/site/index.html" > "$out/.player.js"
node --check "$out/.player.js" 2>/dev/null || {
  echo "the stripped player no longer parses:" >&2; node --check "$out/.player.js"; exit 1; }
rm -f "$out/.player.js"
# Says nothing it should not? Any of these in the customer's page is a leak.
leak=$(grep -o -i -E "babel_productions|daemon|dtrig|the baker|bake time|on the metal|sky\.rs|morpheus|celestial|nemo|c3po|grid-search|erick|nous" "$out/site/index.html" | sort | uniq -c | tr '\n' ' ')
[ -z "$leak" ] || { echo "the customer's page still names internals: $leak" >&2; exit 1; }

grep -q "MEXICO CITY" "$out/site/index.html" && {
  echo "caption stamp failed — the template's own city survived" >&2; exit 1; }
grep -q "2 APRIL 1983" "$out/site/index.html" && {
  echo "caption stamp failed — the template's own date survived" >&2; exit 1; }

cp "$film/film.json"    "$out/site/film.json"
# ── seek.json COMES FROM THE NIGHT BAKE ──────────────────────────────────────
# This shipped wrong once, so the reason is written down rather than remembered.
#
# Both bakes emit a `seek.json` and they are NOT interchangeable. Each names,
# per object, the second of ITS OWN cut at which that cut's camera came nearest.
# The player seeks the night cut. An index built against the film cut therefore
# hands it a second that means nothing there: Antares is t=33.747 in the film
# index, and at 33.747 s the night camera is aimed az 26.2 alt 37.8 — about 150°
# from the star. Measured off night.json, not assumed.
#
# What makes it dangerous is that nothing looks broken. Search finds the name,
# the camera moves, a sky arrives, the panel fills in. It is simply the wrong
# sky, and only someone who knows where Antares should be would ever catch it.
cp "$night/seek.json"   "$out/site/seek.json"
cp "$film/sky.json"     "$out/site/sky.json"
# The tables (facts_birthday.sh) — shipped when the bake has them; every number
# in them is a daemon reply for this date and place.
if [ -r "$film/facts.json" ]; then
  node -e 'JSON.parse(require("fs").readFileSync(process.argv[1]))' "$film/facts.json" 2>/dev/null \
    || { echo "facts.json is not valid JSON" >&2; exit 1; }
  cp "$film/facts.json" "$out/site/facts.json"
fi
cp "$film/figures.json" "$out/site/figures.json"
# The track's bodies and clock (bake_birthday.rs write_bodies). Optional: an
# older bake without it loses the tap on the Moon and planets, the local
# clock and the card's birth-instant line, and nothing else.
if [ -r "$film/bodies.json" ]; then
  node -e 'JSON.parse(require("fs").readFileSync(process.argv[1]))' "$film/bodies.json" 2>/dev/null \
    || { echo "bodies.json is not valid JSON" >&2; exit 1; }
  cp "$film/bodies.json" "$out/site/bodies.json"
fi
cp "$night/film.json"   "$out/site/night.json"
if [ -n "$keys" ]; then
  # One cut of each film per screen shape, one search index per shape (from the
  # NIGHT bake, for the reason above) and the film's poster per shape.
  for k in $keys; do
    for f in $(names "film_$k"); do
      cp "$film/$f"  "$out/site/$f"
      cp "$night/$f" "$out/site/night${f#film}"
    done
    cp "$night/seek_$k.json" "$out/site/seek_$k.json"
    [ -r "$film/poster_$k.png" ] && cp "$film/poster_$k.png" "$out/site/poster_$k.png"
  done
  # Which encodings exist, for the player to choose between. Empty list = the
  # plain film_<shape>.mp4 names.
  printf '{"codecs":[%s]}\n' "$(for c in $codecs; do printf '"%s",' "$c"; done | sed 's/,$//')" \
    > "$out/site/cuts.json"
else
  cp "$film/film.mp4"  "$out/site/film.mp4"
  cp "$night/film.mp4" "$out/site/night.mp4"
  [ -r "$film/poster.png" ] && cp "$film/poster.png" "$out/site/poster.png"
fi

# ── THE INSTALLED APP ───────────────────────────────────────────────────────
# The product is a link that installs: a manifest, an icon cut from the film's
# own poster, and a service worker that keeps the film working offline once it
# has been opened (player/birthday/sw.js). The worker's cache is named for the
# exact bytes shipped, so a re-bundled film replaces the old one on the device.
site="$out/site"
poster_src=""
for p in "$site/poster_169.png" "$site/poster.png"; do [ -r "$p" ] && { poster_src="$p"; break; }; done
[ -n "$poster_src" ] || { echo "no poster to cut the app icon from" >&2; exit 1; }
for s in 512 192; do
  ffmpeg -v error -y -i "$poster_src" -vf "crop='min(iw,ih)':'min(iw,ih)',scale=$s:$s:flags=lanczos" \
    "$site/icon-$s.png" || { echo "icon $s failed" >&2; exit 1; }
done
short=$(echo "$place" | sed 's/,.*//')
cat > "$site/manifest.webmanifest" <<MANIFEST
{
  "name": "$title",
  "short_name": "$short",
  "start_url": ".",
  "scope": ".",
  "display": "standalone",
  "orientation": "any",
  "background_color": "#000000",
  "theme_color": "#000000",
  "icons": [
    { "src": "icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any" },
    { "src": "icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any" }
  ]
}
MANIFEST
node -e 'JSON.parse(require("fs").readFileSync(process.argv[1]))' "$site/manifest.webmanifest" \
  || { echo "manifest is not valid JSON (a quote in the place name?)" >&2; exit 1; }
shell=$(cd "$site" && ls ./*.json ./*.png ./manifest.webmanifest 2>/dev/null | sed 's|^|"|; s|$|"|' | tr '\n' ',' )
shell="[\"./\",\"./index.html\",${shell%,}]"
tag=$(cd "$site" && ls -l --time-style=+ | awk '{print $5, $NF}' | sha256sum | cut -c1-16)
awk '!/^[ \t]*\/\//' "$here/player/birthday/sw.js" \
  | sed -e "s|__CACHE__|sky-$tag|" -e "s|__SHELL__|$shell|" > "$site/sw.js"
node --check "$site/sw.js" || { echo "sw.js does not parse" >&2; exit 1; }
leak=$(grep -o -i -E "app_forge|pwa\.rs|babel|daemon|celestial|morpheus|erick|nous" "$site/sw.js" | sort -u | tr '\n' ' ')
[ -z "$leak" ] || { echo "sw.js still names internals: $leak" >&2; exit 1; }

# ── NO ZIP ──────────────────────────────────────────────────────────────────
# The product is the hosted site, installable from its link. A zip of files is
# not something a phone can open, so the offline single-file build below runs
# only when asked for (BUNDLE_OFFLINE=1) and never for a square master.
if [ "${BUNDLE_OFFLINE:-0}" = 1 ] && [ -z "$keys" ]; then

# ── the offline single file ──────────────────────────────────────────────────
# Built by splitting the player at its <script> and injecting one assignment
# before it. The sidecars are valid JSON, therefore valid JS object literals,
# so they are pasted verbatim — no re-encoding, no parser, nothing that could
# quietly alter a coordinate.
#
# The one hazard is `</script>` appearing inside a JSON string, which would end
# the block early. Star names cannot contain it, but the check is one line and
# the failure would be silent, so it is made loud instead.
for f in film night seek sky figures; do
  src="$out/site/$f.json"
  if grep -q '</script' "$src"; then
    echo "refusing to inline $f.json: it contains </script" >&2; exit 1
  fi
done

emb="$out/.embed.js"
{
  echo '<script id="embed">window.EMBED={'
  printf '"film.json":';    cat "$out/site/film.json";    echo ','
  printf '"night.json":';   cat "$out/site/night.json";   echo ','
  printf '"seek.json":';    cat "$out/site/seek.json";    echo ','
  printf '"sky.json":';     cat "$out/site/sky.json";     echo ','
  printf '"figures.json":'; cat "$out/site/figures.json"; echo
  echo '};</script>'
} > "$emb"

# Inject before </head> — that is, BEFORE the player's own <script>.
#
# It has to be before, and the reason is worth writing down because the obvious
# placement (just before </body>, after everything) FAILS and fails quietly.
# `boot()` is an async IIFE, but the `.map()` that reads `window.EMBED` sits in
# its FIRST synchronous chunk — everything up to the first `await` runs the
# instant the script is parsed. So an EMBED assigned later in the document is
# assigned too late: boot has already decided to `fetch()`, gets the server's
# 404 page, and dies on `Unexpected token '<'`. Observed, not theorised.
#
# `window.EMBED = {…}` touches no DOM, so nothing is lost by running it early.
awk -v embf="$emb" '
  /<\/head>/ && !done {
    while ((getline line < embf) > 0) print line
    close(embf); done = 1
  }
  { print }
' "$out/site/index.html" > "$out/offline/index.html"
rm -f "$emb"

grep -q 'window.EMBED={' "$out/offline/index.html" || {
  echo "inline failed — no EMBED in the offline file" >&2; exit 1; }
# The assignment must come before the player's script, or it is inert.
emb_ln=$(grep -n 'window.EMBED={' "$out/offline/index.html" | head -1 | cut -d: -f1)
scr_ln=$(grep -n '^<script>' "$out/offline/index.html" | head -1 | cut -d: -f1)
[ -n "$scr_ln" ] && [ "$emb_ln" -lt "$scr_ln" ] || {
  echo "EMBED is at line $emb_ln but the player script starts at $scr_ln — too late" >&2
  exit 1; }

cp "$out/site/film.mp4"  "$out/offline/film.mp4"
cp "$out/site/night.mp4" "$out/offline/night.mp4"
[ -r "$out/site/poster.png" ] && cp "$out/site/poster.png" "$out/offline/poster.png"

# A folder of loose files is not a handover. Zip it so what the customer gets is
# one object that survives a chat client.
slug=$(echo "$title" | tr 'A-Z ' 'a-z_' | tr -cd 'a-z0-9_-')
( cd "$out/offline" && zip -q -r "../${slug}.zip" . ) || {
  echo "zip failed (is zip installed?)" >&2; exit 1; }
fi
rmdir "$out/offline" 2>/dev/null

echo "bundle → $out"
echo
printf '  %-22s %s\n' "site/ (hosted)" "$(du -sh "$out/site" | cut -f1)"
ls -la "$out/site" | awk 'NR>3 {printf "    %-16s %10d\n", $9, $5}'
echo
if [ -d "$out/offline" ]; then
  printf '  %-22s %s\n' "offline/ (one file)" "$(du -sh "$out/offline" | cut -f1)"
  ls -la "$out/offline" | awk 'NR>3 {printf "    %-16s %10d\n", $9, $5}'
  echo
  printf '  %-22s %10d bytes\n' "${slug}.zip" "$(stat -c%s "$out/${slug}.zip")"
  echo
fi
printf '  seek index: %s framed entries projected through their own frame, all inside (worst at %s of the edge)\n' \
  "$seek_checked" "$seek_worst"
