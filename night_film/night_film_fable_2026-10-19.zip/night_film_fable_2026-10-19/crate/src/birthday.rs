//! birthday — THE director of the birth-sky film. ONE copy, shared.
//! ============================================================================
//! Erick J. Llamas — Nous Research Centre
//!
//! The film is a BAKED VIDEO. It is not rendered live; it is rendered once, on
//! the metal, per customer, and delivered finished. This module is the director
//! that decides, for any film-second: which real daemon sample is on screen,
//! where the camera points, and how much Sun-light is in the frame.
//!
//! It lives HERE, in `babel_productions`, and not in the wasm shell, because
//! two very different callers must agree on it exactly:
//!
//!   • `examples/bake_birthday.rs` — the native, shard-parallel baker that
//!     renders the frames that ship to the customer.
//!   • `morpheus_web::BirthdayFilm` — the browser shell, which no longer paints
//!     the sky but must still answer "what is that?" and "where is Orion?"
//!     ABOUT THE BAKED FRAME.
//!
//! If the director were duplicated, the shell's hit-test would invert a camera
//! the baker never used and every answer would be quietly wrong. One copy.
//!
//! ── HONESTY CONTRACT ────────────────────────────────────────────────────────
//! Nothing celestial is computed here. Every position comes from a real
//! celestial-daemon sample in the baked track; a frame shows ONE such sample,
//! never an interpolation between two. What this module computes is only
//! presentation: which sample maps to which film-second, the camera move, and
//! the Sun-on/Sun-off cross-dissolve.

use morpheus::celestial_client::{SkyMoon, SkyPlanet, SkyScene, SkySun};
use crate::sky as bsky;

/// The shape of the animation's camera sweep. These four numbers decide how much
/// of the customer's sky the film actually shows, so they are not a matter of
/// taste — they were grid-searched against the coverage the probe measures, and
/// the defaults here are the winner. They stay overridable natively so the search
/// can be re-run when the path changes; the shipped film always uses the
/// defaults, so the baker and the browser can never disagree.
#[derive(Clone, Copy, Debug)]
pub struct SweepPath {
    /// Degrees of azimuth turned over the whole animation. Sign is direction.
    pub pan_deg: f64,
    /// Centre altitude of the sweep, degrees.
    pub alt_base: f64,
    /// How far the aim rises and falls either side of `alt_base`, degrees.
    pub alt_amp: f64,
    /// Complete rise-and-fall cycles over the animation. More cycles trade a
    /// calmer camera for a fuller sweep of the dome.
    pub alt_cycles: f64,
}

/// Grid-searched 2026-09-03 against `birthday_film_probe` coverage on the
/// Mexico City 1983-04-02 track (720 samples). Coverage of the named stars the
/// film paints, as the sweep changes:
///
///   pan −720 → 88.9%   pan 360 → 91.4%   pan 720 → 95.0%   pan 1080 → 95.2%
///   one rise-and-fall (cycles 1) → 92.1%;  two-and-a-half → 95.0%
///
/// Azimuth turn dominates; the altitude shape is worth ~3 points and the centre
/// height almost nothing. 1080° buys six more stars than 720° and costs a third
/// more camera rotation, so 720° wins on the film being watchable.
///
/// (My prior — that turning AGAINST the sky's own rotation would cover more of
/// it — was simply wrong: −720° is the worst of everything measured.)
pub const SWEEP: SweepPath = SweepPath {
    pan_deg: 720.0, alt_base: 36.0, alt_amp: 16.0, alt_cycles: 2.5,
};

#[cfg(not(target_arch = "wasm32"))]
fn sweep_path() -> SweepPath {
    let g = |k: &str, d: f64| std::env::var(k).ok().and_then(|v| v.parse().ok()).unwrap_or(d);
    SweepPath {
        pan_deg:    g("BIRTHDAY_PAN",        SWEEP.pan_deg),
        alt_base:   g("BIRTHDAY_ALT_BASE",   SWEEP.alt_base),
        alt_amp:    g("BIRTHDAY_ALT_AMP",    SWEEP.alt_amp),
        alt_cycles: g("BIRTHDAY_ALT_CYCLES", SWEEP.alt_cycles),
    }
}
#[cfg(target_arch = "wasm32")]
fn sweep_path() -> SweepPath { SWEEP }

/// The PLANETARIUM sweep. A different shape from the cinematic one, because it
/// answers a different question.
///
/// The film's sweep is a band above the horizon: it must stay watchable, so it
/// never tips the camera at the ground and never looks straight up. The
/// planetarium pass has no ground — it runs with the horizon occlusion off —
/// so its only job is to LOOK EVERYWHERE. It therefore rocks through the whole
/// altitude range, negative altitudes included, while it pans.
///
/// Grid-searched, like the cinematic one. Never guessed. Measured 2026-09-04 on
/// the Mexico City 1983-04-02 track, 1280×720, counting seekable objects out of
/// 3,300:
///
///   pan  720 amp 60 cyc 2.5 → 3275     pan 1080 amp 60 cyc 3.5 → 3275
///   pan 1440 amp 65 cyc 4.5 → 3275     pan 1080 amp 70 cyc 5.5 → 3275
///   pan 1440 amp 70 cyc 6.5 → 3275     pan 1800 amp 75 cyc 7.5 → 3275
///
/// Every shape ties, which is the interesting result: once the ground is gone
/// the camera is no longer what limits reach. So the gentlest sweep wins — the
/// same coverage with the least camera motion to watch.
///
/// The 25 that remain unreachable are ALL fainter than magnitude 9.1 (Barnard's
/// Star, Proxima Centauri, Wolf 359, the quasar 3C 273). They are not missed by
/// the camera; they are below the render's magnitude cutoff, invisible to the
/// naked eye, and no camera path can recover them. 3,275/3,300 = 99.2%.
///
/// RE-SEARCHED 2026-09-28 on a second measure, because "seekable" alone let
/// the index send an object to a moment it was BELOW the horizon although it
/// rose that day. Pai 2026-09-04 track, 108 shapes, sidecar-only (every shape
/// still frames 3,285 objects and keeps free-look at 100%):
///
///   pan  720 amp 60 cyc 2.5 (old) → 340 stars + 11 constellations sent below
///   pan 1080 amp 60 cyc 4.5 (new) →  11 stars +  1 constellation  sent below
///
/// Then searched jointly with `NIGHT_SEEK_WEIGHTS` (5 sweeps × 18 weightings),
/// scored also on how far off centre each object lands. Final, Pai track:
/// nothing that rose above 5° is sent below the horizon; the 12 that are
/// never cleared 5° at all (Musca, Dorado, Pavo, Indus from 19° N); median
/// landing 66 px off centre; free-look 100%, worst gap 47.0° (was 57.5°).
///
/// And once more for the SQUARE MASTER, where every screen shape needs its own
/// index — the tall shapes see less of the sky side to side. 24 sweeps, each
/// scored over all four shapes (objects sent below the horizon though they rose
/// above 5°; entries needing more than 2× enlargement to centre):
///
///   pan 1080 amp 60 cyc 4.5 → 5 below (9:16 and 3:4), 200+ over 2×
///   pan 1440 amp 70 cyc 6.5 → 0 below in every shape,   55 over 2×
///
/// Played over 60 s rather than 40 the scores are identical and the camera pans
/// 24°/s instead of 36°/s — the calmer film is worth the extra frames.
///
/// RE-SEARCHED 2026-10-19 for the LOOP. 6.5 cycles ends the altitude sine on
/// a down-stroke and restarts it on an up-stroke: the camera reverses its
/// vertical direction at the wrap (−1.59°/frame → +1.59°/frame, read off the
/// shipped night.json). A whole number of cycles is continuous in position and
/// in velocity. Scored over the sidereal-day span (see `night_last`), all four
/// shapes, with the same measures as above (the sidecar-only scorer ported to
/// `test_tools/predict.py` reproduces the shipped sweep exactly: 55 entries
/// over 2× across the shapes, 0 sent below the horizon):
///
///   cyc 6.5 amp 70 (shipped)  → over-2× 9/29/9/8,   0 below,  free-look worst 22.3°
///   cyc 6.0 amp 70            → over-2× 16/78/14/16, 0 below, free-look worst 50.6°
///   cyc 7.0 amp 70            → over-2× 8/21/7/11,   1 star below in 9:16
///   cyc 7.0 amp 65            → over-2× 8/19/9/10,   0 below,  free-look worst 24.5°  ← this
///   cyc 8.0 (any amp)         → free-look worst ≥ 49°
///
/// 7 cycles at 65° keeps every object up and framed in every shape, centres
/// them a little better than the shipped sweep (46 over-2× against 55), and
/// gives up 2° of free-look worst gap for a camera that does not bounce.
pub const NIGHT_SWEEP: SweepPath = SweepPath {
    pan_deg: 1440.0, alt_base: 0.0, alt_amp: 65.0, alt_cycles: 7.0,
};

#[cfg(not(target_arch = "wasm32"))]
fn night_sweep() -> SweepPath {
    let g = |k: &str, d: f64| std::env::var(k).ok().and_then(|v| v.parse().ok()).unwrap_or(d);
    SweepPath {
        pan_deg:    g("NIGHT_PAN",        NIGHT_SWEEP.pan_deg),
        alt_base:   g("NIGHT_ALT_BASE",   NIGHT_SWEEP.alt_base),
        alt_amp:    g("NIGHT_ALT_AMP",    NIGHT_SWEEP.alt_amp),
        alt_cycles: g("NIGHT_ALT_CYCLES", NIGHT_SWEEP.alt_cycles),
    }
}
#[cfg(target_arch = "wasm32")]
fn night_sweep() -> SweepPath { NIGHT_SWEEP }

/// How the planetarium pass chooses among the moments an object was UP:
/// (centring, altitude, darkness) weights. Centring leads, because the player
/// can only centre an object that lands off-centre by enlarging the film.
pub const NIGHT_SEEK_WEIGHTS: (f64, f64, f64) = (100.0, 0.0, 0.0);
/// Altitude weight for the Sun, Moon and planets in the planetarium pass.
pub const NIGHT_SEEK_BODY_ALT: f64 = 1.0;

#[cfg(not(target_arch = "wasm32"))]
fn night_seek_weights() -> (f64, f64, f64) {
    let g = |k: &str, d: f64| std::env::var(k).ok().and_then(|v| v.parse().ok()).unwrap_or(d);
    (g("NIGHT_W_CENTRE", NIGHT_SEEK_WEIGHTS.0), g("NIGHT_W_ALT", NIGHT_SEEK_WEIGHTS.1),
     g("NIGHT_W_DARK", NIGHT_SEEK_WEIGHTS.2))
}
#[cfg(target_arch = "wasm32")]
fn night_seek_weights() -> (f64, f64, f64) { NIGHT_SEEK_WEIGHTS }

/// The index of the sample at which local sidereal time has advanced one full
/// turn from the first sample — the last frame of a star-closed loop. The LST
/// column wraps at 360°, so the advance is accumulated step by step. A track
/// shorter than a sidereal day returns its last index.
pub fn sidereal_last(lst: &[f64]) -> usize {
    let n = lst.len();
    if n < 2 { return n.saturating_sub(1); }
    let (mut adv, mut best, mut best_d) = (0.0f64, n - 1, f64::MAX);
    for i in 1..n {
        adv += (lst[i] - lst[i - 1]).rem_euclid(360.0);
        let d = (adv - 360.0).abs();
        if d < best_d { best_d = d; best = i; }
        if adv > 360.0 + 180.0 { break; }
    }
    if adv < 360.0 - 1.0 && best_d > 1.0 { return n - 1; }   // never got round
    best
}

// ── keyframe + blend helpers (moved verbatim from the wasm shell) ────────────

/// A smoothstep-interpolated keyframe track (t, value). Used for camera moves
/// and light fades, where a soft in/out is what the eye wants.
pub fn key_track(keys: &[(f64, f64)], t: f64) -> f64 {
    if keys.is_empty() { return 0.0; }
    if t <= keys[0].0 { return keys[0].1; }
    let last = keys[keys.len() - 1];
    if t >= last.0 { return last.1; }
    for w in keys.windows(2) {
        let (a, b) = (w[0], w[1]);
        if t >= a.0 && t <= b.0 {
            let u = (t - a.0) / (b.0 - a.0);
            let s = u * u * (3.0 - 2.0 * u);
            return a.1 + (b.1 - a.1) * s;
        }
    }
    last.1
}

/// Cross-dissolve two RGBA buffers: a=0 → `on` colours, a=1 → `off` night view.
/// Integer fixed-point blend, RGBA unrolled — no per-byte float math.
pub fn dissolve(on: &[u8], off: &[u8], a: f64) -> Vec<u8> {
    let af = (a.clamp(0.0, 1.0) * 256.0) as u32;
    let ai = 256 - af;
    let n = on.len().min(off.len());
    let mut out = vec![0u8; n];
    let mut k = 0;
    while k + 4 <= n {
        out[k]     = ((on[k]     as u32 * ai + off[k]     as u32 * af) >> 8) as u8;
        out[k + 1] = ((on[k + 1] as u32 * ai + off[k + 1] as u32 * af) >> 8) as u8;
        out[k + 2] = ((on[k + 2] as u32 * ai + off[k + 2] as u32 * af) >> 8) as u8;
        out[k + 3] = 255;
        k += 4;
    }
    out
}

/// Extract the first `"key":"string"` from a flat JSON meta object ("" if absent).
pub fn meta_str(s: &str, key: &str) -> String {
    let kq = format!("\"{key}\":\"");
    if let Some(p) = s.find(&kq) {
        let rest = &s[p + kq.len()..];
        if let Some(end) = rest.find('"') { return rest[..end].to_string(); }
    }
    String::new()
}

/// Extract the first `"key":<number>` from a flat JSON meta object.
pub fn meta_num(s: &str, key: &str) -> f64 {
    let kq = format!("\"{key}\":");
    if let Some(p) = s.find(&kq) {
        let rest = &s[p + kq.len()..];
        let end = rest.find(|c: char| c == ',' || c == '}').unwrap_or(rest.len());
        return rest[..end].trim().trim_matches('"').parse().unwrap_or(0.0);
    }
    0.0
}

// ── the night-weighted clock ────────────────────────────────────────────────

/// How the sky is lit at one sample. Boundaries are the standard ones: the Sun
/// above the horizon is day; down to −18° is twilight (civil through
/// astronomical); below that the sky has stopped changing and it is night.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Light { Day, Twilight, Night }

impl Light {
    pub fn of(sun_alt_deg: f64) -> Light {
        if sun_alt_deg > 0.0 { Light::Day }
        else if sun_alt_deg > -18.0 { Light::Twilight }
        else { Light::Night }
    }
    pub fn name(self) -> &'static str {
        match self { Light::Day => "day", Light::Twilight => "twilight", Light::Night => "night" }
    }
    /// Screen-seconds spent per unit of REAL time in this lighting class.
    ///
    /// The brief: *"render the entire video at night, and we just use some parts
    /// of the day as we do which is nice, because sunrise and sunset look nice,
    /// however, the main part of it is the video at night."*
    ///
    /// So: twilight is the slowest thing on screen — the sunset going in and the
    /// sunrise coming out are the two most beautiful minutes of the real day and
    /// they get dwelt on. Night is the body. The day is present, and honest, but
    /// it runs past.
    ///
    /// These are ratios, not shares. The actual shares fall out of how much real
    /// day/twilight/night this particular birth latitude and season HAS, and are
    /// reported by `Warp::share`.
    pub fn density(self) -> f64 {
        match self { Light::Day => 0.6, Light::Twilight => 9.0, Light::Night => 3.5 }
    }
}

/// One monotone piece of the clock: track fraction `[s0,s1]` shown over screen
/// fraction `[a0,a1]`, all of it lit the same way.
#[derive(Clone, Copy, Debug)]
pub struct WarpSeg {
    pub a0: f64, pub a1: f64,
    pub s0: f64, pub s1: f64,
    pub light: Light,
}

/// The film clock: a monotone, piecewise-linear map between screen fraction and
/// track fraction, built FROM THE TRACK'S OWN SUN ALTITUDES. Nothing is assumed
/// about sunrise and sunset times — the daemon's samples are scanned and the
/// lighting runs come out of the data, so a polar summer with no night at all
/// degrades to a single day segment instead of dividing by zero.
#[derive(Clone, Debug)]
pub struct Warp { pub segs: Vec<WarpSeg> }

impl Warp {
    /// Build the clock from the per-sample Sun altitudes of the baked track.
    pub fn from_sun_alts(sun_alt: &[f64]) -> Warp {
        let n = sun_alt.len();
        if n < 2 {
            return Warp { segs: vec![WarpSeg { a0: 0.0, a1: 1.0, s0: 0.0, s1: 1.0, light: Light::Night }] };
        }
        let last = (n - 1) as f64;
        // Maximal runs of one lighting class, in track order.
        let mut runs: Vec<(usize, usize, Light)> = Vec::new();
        let mut start = 0usize;
        let mut cur = Light::of(sun_alt[0]);
        for i in 1..n {
            let l = Light::of(sun_alt[i]);
            if l != cur { runs.push((start, i, cur)); start = i; cur = l; }
        }
        runs.push((start, n - 1, cur));

        // Weight each run by (real length × its screen density) and normalise.
        let mut weights: Vec<f64> = runs.iter()
            .map(|&(i0, i1, l)| ((i1 - i0) as f64 / last) * l.density())
            .collect();
        let total: f64 = weights.iter().sum();
        if total <= 0.0 { weights = vec![1.0 / runs.len() as f64; runs.len()]; }
        let total: f64 = weights.iter().sum();

        let mut segs = Vec::with_capacity(runs.len());
        let mut a = 0.0;
        for (k, &(i0, i1, l)) in runs.iter().enumerate() {
            let da = weights[k] / total;
            segs.push(WarpSeg {
                a0: a, a1: (a + da).min(1.0),
                s0: i0 as f64 / last, s1: i1 as f64 / last,
                light: l,
            });
            a += da;
        }
        if let Some(z) = segs.last_mut() { z.a1 = 1.0; z.s1 = 1.0; }
        Warp { segs }
    }

    /// Screen fraction → track fraction. This is the film clock.
    pub fn track_at(&self, a: f64) -> f64 {
        let a = a.clamp(0.0, 1.0);
        for s in &self.segs {
            if a <= s.a1 {
                let d = s.a1 - s.a0;
                if d <= 0.0 { return s.s0; }
                return s.s0 + (s.s1 - s.s0) * ((a - s.a0) / d);
            }
        }
        1.0
    }

    /// Track fraction → screen fraction. The INVERSE, and the reason the seek
    /// index is possible: given the sample on which Orion stands highest, this
    /// says which film-second to jump to.
    pub fn screen_at(&self, s: f64) -> f64 {
        let s = s.clamp(0.0, 1.0);
        for w in &self.segs {
            if s <= w.s1 {
                let d = w.s1 - w.s0;
                if d <= 0.0 { return w.a0; }
                return w.a0 + (w.a1 - w.a0) * ((s - w.s0) / d);
            }
        }
        1.0
    }

    /// Share of total screen time given to one lighting class. Reported, not
    /// asserted — this is the number that says whether the film really is
    /// "mostly night" for THIS birth.
    pub fn share(&self, light: Light) -> f64 {
        self.segs.iter().filter(|s| s.light == light).map(|s| s.a1 - s.a0).sum()
    }

    /// Share of the REAL elapsed time that is lit this way (the sky's own
    /// fraction, before the clock warps it). The pair of these two numbers is
    /// the whole story of what the warp did.
    pub fn real_share(&self, light: Light) -> f64 {
        self.segs.iter().filter(|s| s.light == light).map(|s| s.s1 - s.s0).sum()
    }
}

// ── the film ────────────────────────────────────────────────────────────────

/// Which act of the film a given second falls in.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Phase { Intro, Hero, Anim }

/// The director's complete state at one film-second. `frame_rgba` renders with
/// exactly this and the shell's hit-test inverts exactly this, so a tap can
/// never be resolved against a camera the viewer was not looking through.
#[derive(Clone, Copy, Debug)]
pub struct Shot {
    pub phase: Phase,
    /// Index of the REAL daemon sample on screen. Not interpolated.
    pub sample: usize,
    pub aim_az: f64,
    pub aim_alt: f64,
    pub fov_deg: f64,
    /// 0 = rendered with the Sun's light, 1 = day drawn as night (full star
    /// field). Values between are a cross-dissolve of the two renders.
    pub sun_off_amt: f64,
}

impl Shot {
    /// Which star cutoff the frame was drawn under — the dominant half of a
    /// cross-dissolve decides, so the hit-test sees the field the viewer sees.
    pub fn sun_off(&self) -> bool { self.sun_off_amt >= 0.5 }
}

/// A loaded birth-sky film: the baked positions track plus the director meta.
pub struct FilmTrack {
    base: SkyScene,
    pub params: bsky::SkyParams,
    /// Planet names, order fixed across the whole track.
    pub names: Vec<String>,
    /// Flat n × cols table of real daemon samples.
    pub frames: Vec<f64>,
    pub cols: usize,
    pub n: usize,
    // director meta, all from the baked track
    pub birth_moon_az: f64, pub birth_moon_alt: f64,
    pub establish_az: f64, pub establish_alt: f64, pub wide_fov: f64,
    pub intro_secs: f64, pub hero_secs: f64, pub anim_secs: f64,
    /// The night-weighted clock, derived from this track's Sun altitudes.
    pub warp: Warp,
    /// THE PLANETARIUM PASS. When set, the film is one single act: no intro, no
    /// hero, no night-weighted clock, and the Sun's light switched off for every
    /// frame of it.
    ///
    /// This exists because the cinematic film cannot answer "show me THIS star".
    /// That film spends its 40 seconds where the sky is beautiful, which means
    /// most of it is night — and a star that happens to be up only at noon is
    /// never on screen in a watchable frame. Kill the sunlight and run the clock
    /// UNIFORMLY through the whole track instead, and local sidereal time sweeps
    /// a full turn, so every star that ever clears the horizon gets its moment
    /// against a dark sky.
    ///
    /// HONESTY CONTRACT: this is not a fake sky. Every frame is still one real
    /// daemon sample and every position is the true one for that instant. The
    /// only thing removed is the Sun's *glare* — the sky as it would look if
    /// daylight did not drown it. That must be said in the UI, not implied.
    pub night_only: bool,
    /// THE SQUARE MASTER. 1.0 renders the frame the director describes. Above
    /// 1.0 every shot's vertical half-field tangent is multiplied by this, so a
    /// SQUARE render with factor 16/9 contains, as its centre 16:9 crop, exactly
    /// the landscape frame — and the phone-portrait and tablet frames as other
    /// centred crops of the same pixels. One camera path, one bake, every screen.
    pub frame_widen: f64,
    /// The track's own calendar and clock, kept for the player's sidecar
    /// (`bodies.json`): the date, the UTC offset in hours, the local hour of
    /// sample 0 and the span of the track in hours. All read off the track's
    /// meta line; the player derives each frame's local time from them.
    pub date: String,
    pub utc_off_h: f64,
    pub birth_local_h: f64,
    pub cycle_h: f64,
    /// THE LOOP OF THE PLANETARIUM PASS. Index of the last sample that pass
    /// runs to. The track is one LUNAR day (25.05 h at Pai), chosen so the
    /// Moon comes back to where it rose; but the stars come back after one
    /// SIDEREAL day (23.93 h), and a pass that runs the whole track wraps with
    /// its star field 16.7° further on than it started — a visible jump at
    /// every loop, 182 px at the 4K centre. Running it to the sample at which
    /// local sidereal time has advanced exactly 360° closes the loop on the
    /// stars (residual −0.02° = 0.2 px on the Pai track). The Moon, which has
    /// moved on ~13° against the stars in that time, still jumps at the wrap
    /// (14.3° here); that is the one seam left, and it is the honest one.
    /// The hour of sky given up (10:00–11:03 the next morning) repeats the
    /// start of the track in everything but the Moon, so the search loses
    /// nothing: every shape still frames 3,285 objects with none sent below
    /// the horizon. Falls back to the whole track if it is shorter than a
    /// sidereal day.
    night_last: usize,
    /// Paint the Milky Way band, dust rift and deep-sky glows — in the NIGHT
    /// VIEW only. The film renders a twilight frame twice, sunlit and as the
    /// night view, and cross-dissolves them; painted into the sunlit render the
    /// dust rift is a black stripe across a bright evening sky (measured on the
    /// Pai film at Sun −2°). Confined to the night view, the band fades in as the
    /// sky really darkens. See `light`.
    pub milky_way: bool,
    /// Cached static intro pair (w, h, sun-on, sun-off) — the intro holds one
    /// instant with one camera, so its two renders are identical every frame.
    intro_cache: Option<(u32, u32, Vec<u8>, Vec<u8>)>,
}

/// Column layout of a track row. Fixed by `morpheus::sky_track::bake_track`.
pub const COL_LST: usize = 0;
pub const COL_SUN_AZ: usize = 1;
pub const COL_SUN_ALT: usize = 2;
pub const COL_MOON_AZ: usize = 5;
pub const COL_MOON_ALT: usize = 6;
pub const COL_PLANET0: usize = 14;

impl FilmTrack {
    /// Load from the two pieces the browser already has: the meta line and the
    /// flattened CSV body.
    pub fn from_parts(meta_json: &str, frames: &[f64]) -> Result<FilmTrack, String> {
        let n = meta_num(meta_json, "n_frames") as usize;
        if n == 0 || frames.is_empty() { return Err("empty track".into()); }
        let cols = frames.len() / n;
        if cols <= COL_PLANET0 { return Err(format!("track has {cols} cols, need > {COL_PLANET0}")); }

        let npl = meta_num(meta_json, "npl") as usize;
        // The offset is taken from the needle's own length rather than written
        // out. It used to be a hand-counted `+ 10` against an 11-byte key, which
        // left the opening `[` glued to the first name — every track ever parsed
        // called Mercury `["Mercury`. Nothing showed it until the planets became
        // searchable, because the name was only ever carried, never printed.
        const PLANETS_KEY: &str = "\"planets\":[";
        let mut names: Vec<String> = if let Some(p) = meta_json.find(PLANETS_KEY) {
            let rest = &meta_json[p + PLANETS_KEY.len()..];
            let end = rest.find(']').unwrap_or(0);
            rest[..end].split(',').map(|s| s.trim().trim_matches('"').to_string())
                .filter(|s| !s.is_empty()).collect()
        } else { Vec::new() };
        while names.len() < npl { names.push(String::new()); }

        let lat = meta_num(meta_json, "lat");
        let lon = meta_num(meta_json, "lon");

        // The clock comes from the track's own Sun altitudes, not from the meta's
        // sunset/sunrise fractions — the samples ARE the sky.
        let sun_alt: Vec<f64> = (0..n).map(|i| frames[i * cols + COL_SUN_ALT]).collect();
        let warp = Warp::from_sun_alts(&sun_alt);
        let night_last = sidereal_last(&(0..n).map(|i| frames[i * cols + COL_LST]).collect::<Vec<_>>());

        Ok(FilmTrack {
            base: SkyScene {
                lat, lon, lst_deg: 0.0,
                sun: SkySun { az: 0.0, alt: 0.0, ang_size_deg: 0.53, temperature_k: 5772.0 },
                moon: SkyMoon { az: 0.0, alt: 0.0, ang_size_deg: 0.52, illum_fraction: 0.5,
                                phase_angle_deg: 90.0, bright_limb_pa_deg: 0.0, waxing: true,
                                pole_az: 0.0, pole_alt: 0.0 },
                planets: Vec::new(), stars: Vec::new(),
                obscuration: 0.0, corona: None,
            },
            params: bsky::SkyParams {
                year: 1983, month: 4, day: 2, hour: 0.0,
                lat, lon, maglim: meta_num(meta_json, "maglim"),
                aim_az: 140.0, aim_alt: 45.0, fov_deg: 120.0,
                exposure: -1.0, moon_h_exag: 15.0,
            },
            names, frames: frames.to_vec(), cols, n,
            birth_moon_az: meta_num(meta_json, "birth_moon_az"),
            birth_moon_alt: meta_num(meta_json, "birth_moon_alt"),
            establish_az: meta_num(meta_json, "establish_az"),
            establish_alt: meta_num(meta_json, "establish_alt"),
            wide_fov: meta_num(meta_json, "wide_fov"),
            intro_secs: meta_num(meta_json, "intro_secs"),
            hero_secs: meta_num(meta_json, "hero_secs"),
            anim_secs: meta_num(meta_json, "anim_secs"),
            warp,
            date: meta_str(meta_json, "date"),
            utc_off_h: meta_num(meta_json, "utc_off"),
            birth_local_h: meta_num(meta_json, "birth_local"),
            cycle_h: meta_num(meta_json, "cycle_h"),
            night_last,
            night_only: false,
            frame_widen: 1.0,
            milky_way: false,
            intro_cache: None,
        })
    }

    /// Load from the whole `birthday_track.json` text (meta line + CSV body) —
    /// what the native baker reads off disk.
    pub fn from_text(text: &str) -> Result<FilmTrack, String> {
        let nl = text.find('\n').ok_or("track has no body")?;
        let meta = &text[..nl];
        let mut flat: Vec<f64> = Vec::new();
        for line in text[nl + 1..].lines() {
            let line = line.trim();
            if line.is_empty() { continue; }
            for p in line.split(',') {
                flat.push(p.trim().parse::<f64>().map_err(|_| format!("bad number {p:?}"))?);
            }
        }
        FilmTrack::from_parts(meta, &flat)
    }

    /// Override the animation length — the browser preview and the sellable bake
    /// do not have to be the same runtime.
    pub fn set_anim_secs(&mut self, s: f64) { self.anim_secs = s.max(1.0); self.intro_cache = None; }

    /// The planetarium pass has no title acts to sit through — it is a lookup
    /// surface, and a seek into it should never land in an intro.
    pub fn loop_secs(&self) -> f64 {
        if self.night_only { self.anim_secs }
        else { self.intro_secs + self.hero_secs + self.anim_secs }
    }

    /// Switch this track to the planetarium pass. See `night_only`.
    pub fn set_night_only(&mut self, on: bool) {
        self.night_only = on;
        self.intro_cache = None;    // the intro act no longer exists
    }

    /// How far local sidereal time at this cut's last frame is from its first,
    /// modulo a full turn — the star-field jump at the loop, in degrees.
    pub fn loop_lst_residual_deg(&self) -> f64 {
        let last = if self.night_only { self.night_last } else { self.n.saturating_sub(1) };
        let d = (self.lst(last) - self.lst(0)).rem_euclid(360.0);
        if d > 180.0 { d - 360.0 } else { d }
    }
    /// Does this cut's last frame run on into its first? True for the
    /// planetarium pass when the track holds a sidereal day and the camera
    /// path closes (a whole number of altitude cycles, a whole number of
    /// azimuth turns). Never for the cinematic cut: it ends the next morning
    /// and restarts at the birth hour.
    pub fn loop_closed(&self) -> bool {
        if !self.night_only { return false; }
        let sw = night_sweep();
        self.loop_lst_residual_deg().abs() < 0.3
            && (sw.alt_cycles - sw.alt_cycles.round()).abs() < 1e-9
            && (sw.pan_deg.rem_euclid(360.0)).min(360.0 - sw.pan_deg.rem_euclid(360.0)) < 1e-9
    }

    /// Sun altitude of one sample, straight from the track row.
    pub fn sun_alt(&self, si: usize) -> f64 { self.frames[si * self.cols + COL_SUN_ALT] }
    /// Local sidereal time of one sample — what places the compiled star catalogue.
    pub fn lst(&self, si: usize) -> f64 { self.frames[si * self.cols + COL_LST] }
    pub fn lat(&self) -> f64 { self.base.lat }
    pub fn lon(&self) -> f64 { self.base.lon }

    /// Build the SkyScene for sample `si` by overwriting the base's time-varying
    /// fields with that real daemon sample.
    pub fn scene_at(&self, si: usize) -> SkyScene {
        let mut sc = self.base.clone();
        let b = si.min(self.n.saturating_sub(1)) * self.cols;
        let r = &self.frames[b..b + self.cols];
        sc.lst_deg = r[COL_LST];
        sc.sun = SkySun { az: r[1], alt: r[2], ang_size_deg: r[3], temperature_k: r[4] };
        sc.moon = SkyMoon {
            az: r[5], alt: r[6], ang_size_deg: r[7], illum_fraction: r[8],
            phase_angle_deg: r[9], bright_limb_pa_deg: r[10], waxing: r[11] != 0.0,
            pole_az: r[12], pole_alt: r[13],
        };
        sc.planets = (0..self.names.len()).map(|k| {
            let o = COL_PLANET0 + k * 4;
            SkyPlanet { name: self.names[k].clone(), az: r[o], alt: r[o + 1],
                        mag: r[o + 2], ang_size_deg: r[o + 3] }
        }).collect();
        sc
    }

    /// How much Sun-light is in the frame at screen fraction `a` of the
    /// animation. Now read DIRECTLY off the sample's real Sun altitude rather
    /// than off keyframes: the light in the frame follows the actual Sun.
    ///
    /// Above the horizon the Sun lights the scene (0). Below −6° (civil dusk
    /// gone) there is nothing left to light and the full star field is drawn
    /// (1). Between, the two renders cross-dissolve — which is exactly the
    /// stretch of sky the warp dwells on.
    fn sun_off_for(&self, si: usize) -> f64 {
        let alt = self.sun_alt(si);
        if alt >= 0.0 { 0.0 }
        else if alt <= -6.0 { 1.0 }
        else {
            let u = (-alt) / 6.0;                 // 0 at horizon → 1 at −6°
            (u * u * (3.0 - 2.0 * u)).clamp(0.0, 1.0)
        }
    }

    /// THE DIRECTOR. Everything the film is at film-second `t_sec`.
    /// Set the renderer's Sun-light switch for the next render, and the Milky
    /// Way with it: on only in the night view, and only when this film asked for
    /// it. Both are process-global switches in `sky.rs`, so they are set
    /// together, right before every render, never left to a previous frame.
    fn light(&self, sun_off: bool) {
        bsky::set_sun_light_off(sun_off);
        let want = self.milky_way && sun_off;
        if bsky::dsos_on() != want { bsky::toggle_dsos(); }
    }

    pub fn set_frame_widen(&mut self, k: f64) {
        self.frame_widen = if k.is_finite() && k >= 1.0 { k } else { 1.0 };
        self.intro_cache = None;
    }

    /// THE DIRECTOR, as rendered. `shot_base` decides the film; this widens its
    /// field for the square master (a pure change of frame, not of camera).
    pub fn shot(&self, t_sec: f64) -> Shot {
        let mut s = self.shot_base(t_sec);
        if self.frame_widen != 1.0 {
            let half = (s.fov_deg.to_radians() * 0.5).tan() * self.frame_widen;
            s.fov_deg = (2.0 * half.atan()).to_degrees();
        }
        s
    }

    fn shot_base(&self, t_sec: f64) -> Shot {
        let last = self.n.saturating_sub(1);
        let loop_s = self.loop_secs();
        let t = t_sec.rem_euclid(loop_s);
        let (intro, hero) = (self.intro_secs, self.hero_secs);

        if self.night_only {
            // THE PLANETARIUM PASS — one act, no title cards, no Moon lock.
            //
            // The clock is UNIFORM here, deliberately unlike the cinematic film.
            // The film's night-weighted clock is what makes it watchable, but it
            // is exactly wrong for a lookup surface: it races through the hours
            // either side of noon, so the stars that are up then get a handful of
            // frames and the seek index has almost nothing to choose from. Walk
            // the track at a constant rate and local sidereal time turns a full
            // circle at a constant rate with it, which is what gives every right
            // ascension an equal share of the screen.
            let a = (t / self.anim_secs.max(1e-9)).clamp(0.0, 1.0);
            // Over ONE SIDEREAL DAY of the track, not all of it — see `night_last`.
            let si = ((a * self.night_last as f64).round() as usize).min(last);
            let sw = night_sweep();
            return Shot {
                phase: Phase::Anim, sample: si,
                aim_az: self.establish_az + sw.pan_deg * a,
                // NOT clamped to the horizon, unlike the cinematic film. This
                // pass runs with the ground occlusion off, so there is no floor
                // to stare at — below the horizon line there is simply more sky.
                // Letting the camera dip is the whole reason every star becomes
                // reachable: Orion sits 71° up on this date and the film's
                // 20°–52° band never once looked at it.
                aim_alt: sw.alt_base
                    + sw.alt_amp * (2.0 * std::f64::consts::PI * sw.alt_cycles * a).sin(),
                // No hero to zoom out of, so the frame is the wide dome
                // throughout — the widest honest view of the sky we have.
                fov_deg: self.wide_fov,
                // The whole point: the Sun never lights this pass.
                sun_off_amt: 1.0,
            };
        }

        if t < intro {
            // ACT 0 — a static establishing hold at the birth instant, wide dome
            // on the Sun side, breathing between lit and starlit.
            let keys = [(0.00, 1.0), (0.42, 1.0), (0.54, 0.0), (0.66, 0.0), (0.80, 1.0), (1.00, 1.0)];
            Shot {
                phase: Phase::Intro, sample: 0,
                aim_az: self.establish_az, aim_alt: self.establish_alt, fov_deg: self.wide_fov,
                sun_off_amt: key_track(&keys, t / intro.max(1e-9)).clamp(0.0, 1.0),
            }
        } else if t < intro + hero {
            // ACT 1 — the hero sweep. Clock frozen at the birth instant; camera
            // eases from the wide dome down to the Moon as it stood that moment.
            let v = (t - intro) / hero.max(1e-9);
            let u = v * v * (3.0 - 2.0 * v);
            Shot {
                phase: Phase::Hero, sample: 0,
                aim_az:  self.establish_az  + (self.birth_moon_az  - self.establish_az)  * u,
                aim_alt: self.establish_alt + (self.birth_moon_alt - self.establish_alt) * u,
                fov_deg: self.wide_fov      + (8.0                 - self.wide_fov)      * u,
                sun_off_amt: 1.0,
            }
        } else {
            // ACT 2 — the lunar day, on the night-weighted clock. The camera
            // unlocks from the Moon and sweeps a full turn of azimuth at the wide
            // fov, so over one loop every direction of the sky passes the frame.
            let a = ((t - intro - hero) / self.anim_secs.max(1e-9)).clamp(0.0, 1.0);
            let si = ((self.warp.track_at(a) * last as f64).round() as usize).min(last);
            let fov_keys = [(0.0, 8.0), (0.06, self.wide_fov), (1.0, self.wide_fov)];
            let lock_keys = [(0.0, 1.0), (0.05, 1.0), (0.14, 0.0), (1.0, 0.0)];
            let b = si * self.cols;
            let (m_az, m_alt) = (self.frames[b + COL_MOON_AZ], self.frames[b + COL_MOON_ALT]);

            // The Moon-lock releases on TIME *and* on the Moon itself. On the
            // night-weighted clock the daylight hours fly past, and the Moon can
            // set inside the first second of the animation — a pure time-based
            // release would leave the camera staring at the ground while it
            // followed the Moon down. Fade the lock out as the Moon reaches the
            // horizon; below it, there is nothing to look at.
            let moon_up = ((m_alt - 2.0) / 12.0).clamp(0.0, 1.0);
            let lock = key_track(&lock_keys, a) * moon_up;

            // The sweep. Its shape is `SWEEP`, grid-searched against measured
            // coverage rather than chosen by eye — see `birthday_film_probe`.
            let sw = sweep_path();
            let drift_az = self.birth_moon_az
                + (self.establish_az + sw.pan_deg - self.birth_moon_az) * a;
            let anchor_alt = sw.alt_base
                + sw.alt_amp * (2.0 * std::f64::consts::PI * sw.alt_cycles * a).sin();
            Shot {
                phase: Phase::Anim, sample: si,
                aim_az:  m_az  * lock + drift_az   * (1.0 - lock),
                // Never below the horizon: the frame is a view of the SKY.
                aim_alt: (m_alt * lock + anchor_alt * (1.0 - lock)).clamp(0.0, 85.0),
                fov_deg: key_track(&fov_keys, a),
                sun_off_amt: self.sun_off_for(si),
            }
        }
    }

    /// The film-second at which animation screen fraction `a` is shown.
    pub fn anim_t(&self, a: f64) -> f64 {
        // The planetarium pass has no title acts in front of it, so adding their
        // length here would hand out seek times PAST THE END of that film — the
        // 40-second night cut was being indexed at t = 51.8 s, and every such
        // seek silently fell off the end.
        if self.night_only { a.clamp(0.0, 1.0) * self.anim_secs }
        else { self.intro_secs + self.hero_secs + a.clamp(0.0, 1.0) * self.anim_secs }
    }

    /// The film-second at which real daemon sample `si` is on screen — the
    /// inverse clock, and the thing that turns a search into a seek.
    pub fn t_of_sample(&self, si: usize) -> f64 {
        let last = self.n.saturating_sub(1).max(1) as f64;
        self.anim_t(self.warp.screen_at(si as f64 / last))
    }

    /// Render ONE still of the film's own sky at `t_sec`, but looking wherever
    /// you ask — the personal-planetarium frame.
    ///
    /// This is the answer to the part of the promise a baked film cannot keep by
    /// itself. The camera path is fixed once it is baked, so roughly one named
    /// star in twenty is up, painted, and yet never inside a frame. Rather than
    /// tell the customer "not in this film", the shell renders that ONE frame on
    /// demand and shows it. A frame costs ~100 ms; that is nothing when it is one
    /// frame answering a question, and ruinous only when it is thirty of them a
    /// second — which is exactly why the film is baked and this is not.
    ///
    /// HONESTY CONTRACT: this is the SAME real daemon sample the film shows at
    /// `t_sec`, under the same star cutoff, only looked at from another
    /// direction. Nothing is invented to fill the frame; if the sky is empty
    /// that way, the still is empty.
    pub fn aimed_still(&mut self, w: u32, h: u32, t_sec: f64,
                       az: f64, alt: f64, fov_deg: f64) -> Vec<u8> {
        if self.n == 0 { return vec![0u8; (w as usize) * (h as usize) * 4]; }
        let s = self.shot(t_sec);
        let sc = self.scene_at(s.sample);
        self.params.aim_az = az;
        self.params.aim_alt = alt.clamp(-20.0, 89.0);
        self.params.fov_deg = fov_deg.clamp(4.0, 160.0);
        self.params.hour = 1.0 + s.sample as f64;
        self.light(s.sun_off());
        bsky::render_from_scene(&sc, &self.params, w, h)
    }

    /// Render the film frame at `t_sec`. DOM-free: runs in a browser, a worker,
    /// a native baker, or a bench harness.
    ///
    /// NOTE for the baker: `bsky::render_from_scene` reads process-global state
    /// (the Sun-light kill switch and single-slot scene caches), so frames must
    /// be parallelised across PROCESSES, not threads. See `bake_birthday.rs`.
    pub fn frame_rgba(&mut self, w: u32, h: u32, t_sec: f64) -> Vec<u8> {
        if self.n == 0 { return vec![0u8; (w as usize) * (h as usize) * 4]; }
        let s = self.shot(t_sec);
        self.params.aim_az = s.aim_az;
        self.params.aim_alt = s.aim_alt;
        self.params.fov_deg = s.fov_deg;

        // THE GROUND. The cinematic film keeps it — the solid Earth hiding half
        // the sky is what makes the shot read as a place someone stood. The
        // planetarium pass drops it, so the frame is the whole celestial sphere
        // and a star below the horizon is drawn rather than occluded.
        //
        // Driven through the renderer's own toggle instead of a new setter, so
        // nothing in `sky.rs` has to change to support this.
        if bsky::horizon_off() != self.night_only { bsky::toggle_horizon_off(); }

        if s.phase == Phase::Intro {
            let fresh = match &self.intro_cache {
                Some((cw, ch, _, _)) => *cw != w || *ch != h, None => true };
            if fresh {
                let sc = self.scene_at(0);
                self.params.hour = 0.0;
                self.light(false);
                let on = bsky::render_from_scene(&sc, &self.params, w, h);
                self.light(true);
                let off = bsky::render_from_scene(&sc, &self.params, w, h);
                self.intro_cache = Some((w, h, on, off));
            }
            let (on, off) = match &self.intro_cache {
                Some((_, _, on, off)) => (on, off),
                None => unreachable!("intro_cache populated above"),
            };
            return dissolve(on, off, s.sun_off_amt);
        }

        let sc = self.scene_at(s.sample);
        // A distinct `hour` per sample makes the renderer's scene cache restage.
        self.params.hour = if s.phase == Phase::Hero { 0.0 } else { 1.0 + s.sample as f64 };

        if s.sun_off_amt <= 0.004 {
            self.light(false);
            bsky::render_from_scene(&sc, &self.params, w, h)
        } else if s.sun_off_amt >= 0.996 {
            self.light(true);
            bsky::render_from_scene(&sc, &self.params, w, h)
        } else {
            self.light(false);
            let on = bsky::render_from_scene(&sc, &self.params, w, h);
            self.light(true);
            let off = bsky::render_from_scene(&sc, &self.params, w, h);
            dissolve(&on, &off, s.sun_off_amt)
        }
    }
}

// ── THE SEEK INDEX — what turns a search into a jump ─────────────────────────
//
// The film is a baked video: the camera goes where it goes, when it goes there.
// So "type Orion and the video goes to Orion" cannot mean moving the camera —
// it means finding the FILM-SECOND at which Orion is best placed in the frame
// the customer already owns, and seeking there.
//
// That is a question with one right answer per object, and it does not change
// after the bake. So it is computed ONCE, at bake time, and shipped beside the
// frames: precompute once, read many.
//
// HONESTY CONTRACT: an entry is only marked `framed` if the object really did
// land inside a real frame, painted, above the horizon. An object that never
// does keeps its entry — with `framed:false` and the second at which it came
// closest — so the shell can say what is actually true about it ("up at 03:12,
// but this film's camera never looks that low") instead of silently dropping it.

/// One object's best moment in the film.
#[derive(Clone, Debug)]
pub struct SeekEntry {
    /// "star" | "con" | "sun" | "moon" | "planet"
    ///
    /// The last three are the MOVING bodies. They are not catalogue rows — they
    /// have no fixed RA/Dec to look up, their position is whatever the daemon
    /// said it was at that sample, and the facts worth showing about them are
    /// different (a disc has an angular size and the Moon has a phase; a star
    /// has neither). The names match `sky::search_sky`, which has always found
    /// them in the live path — this makes the BAKED index agree with it.
    pub kind: &'static str,
    /// Stable identity: a HIP number for a star, an IAU code for a constellation.
    pub key: String,
    /// What to show the customer.
    pub name: String,
    /// Constellation IAU code (stars carry theirs; a constellation is its own).
    pub con: String,
    /// The film-second to seek to.
    pub t_sec: f64,
    /// Where it stands at that second.
    pub az: f64,
    pub alt: f64,
    /// True when it really is inside the frame at `t_sec`, painted and up.
    pub framed: bool,
    /// Highest altitude it reaches anywhere in the film — the honest fallback
    /// fact when `framed` is false.
    pub max_alt: f64,
    /// Apparent magnitude (a constellation carries its brightest member's).
    ///
    /// `NaN` where the number is genuinely not held: the Sun and the Moon come
    /// from the daemon without one, and `search_sky` already reports them that
    /// way. NaN is not valid JSON, so `to_json` OMITS the field rather than
    /// inventing a textbook value — an absent key is honest, `-26.74` would be
    /// a number this pipeline never computed.
    pub mag: f64,
    /// Angular diameter, degrees. A real disc has one; a star is a point and
    /// carries `NaN`.
    pub ang_size_deg: f64,
    /// Moon only: lit fraction 0‥1, phase angle, and which way it is going.
    /// `NaN`/`false` for everything else.
    pub illum: f64,
    pub phase_angle_deg: f64,
    pub waxing: bool,
}

impl SeekEntry {
    pub fn to_json(&self) -> String {
        let esc = |s: &str| s.replace('\\', "\\\\").replace('"', "\\\"");
        // Constellations also carry their customary English name, so a customer
        // who types "the swan" rather than "Cygnus" still finds it. Latin is the
        // catalogue's language, not most people's.
        let en = if self.kind == "con" {
            crate::con_meta::english(&self.con)
                .map(|e| format!(",\"english\":\"{}\"", esc(e)))
                .unwrap_or_default()
        } else { String::new() };
        // Every optional number is emitted ONLY when it is actually held. A key
        // that is absent means "this pipeline does not have that fact", which
        // the player can render as silence. A key present with a made-up value
        // would be indistinguishable from a measured one.
        let mut ext = String::new();
        if self.mag.is_finite() {
            ext.push_str(&format!(",\"mag\":{:.2}", self.mag));
        }
        if self.ang_size_deg.is_finite() {
            ext.push_str(&format!(",\"ang\":{:.4}", self.ang_size_deg));
        }
        if self.illum.is_finite() {
            ext.push_str(&format!(",\"illum\":{:.4}", self.illum));
        }
        if self.phase_angle_deg.is_finite() {
            ext.push_str(&format!(",\"phase\":{:.2},\"waxing\":{}",
                                  self.phase_angle_deg, self.waxing));
        }
        format!(
            "{{\"kind\":\"{}\",\"key\":\"{}\",\"name\":\"{}\",\"con\":\"{}\",\
             \"t\":{:.3},\"az\":{:.3},\"alt\":{:.3},\"framed\":{},\
             \"max_alt\":{:.3}{ext}{en}}}",
            self.kind, esc(&self.key), esc(&self.name), esc(&self.con),
            self.t_sec, self.az, self.alt, self.framed, self.max_alt)
    }
}

/// A constellation reduced to ONE direction to aim at: the brightness-weighted
/// mean of its named stars, as a J2000 unit vector.
///
/// Weighted because a constellation's identity is its bright figure, not its
/// faint filler — Orion's centre should sit inside the belt, not be dragged off
/// by a dozen 6th-magnitude stars in the sword. The weight is the star's linear
/// flux, `10^(-0.4·mag)`, which is what "how much this star contributes to what
/// you see" actually means. Nothing here is hand-placed.
pub struct ConCentroid {
    pub iau: &'static str,
    pub ra_deg: f64,
    pub dec_deg: f64,
    /// Brightest member's magnitude — the constellation is visible when it is.
    pub mag: f64,
    pub members: usize,
}

/// Compute the centroid of every constellation that has named stars (all 88).
pub fn constellation_centroids() -> Vec<ConCentroid> {
    use dc_foundation::{dc_sin, dc_cos, dc_asin, dc_atan2};
    const D2R: f64 = std::f64::consts::PI / 180.0;
    let mut out: Vec<ConCentroid> = Vec::new();
    for (code, _, _) in crate::con_meta::IAU_88 {
        let mut v = [0.0f64; 3];
        let mut wsum = 0.0;
        let mut best = f64::MAX;
        let mut members = 0usize;
        for st in crate::star_names::NAMED_STARS.iter().filter(|s| s.con == *code) {
            let (ra, dec, mag) = (st.ra as f64 * D2R, st.dec as f64 * D2R, st.mag as f64);
            let w = (10.0f64).powf(-0.4 * mag);
            let cd = dc_cos(dec);
            v[0] += w * cd * dc_cos(ra);
            v[1] += w * cd * dc_sin(ra);
            v[2] += w * dc_sin(dec);
            wsum += w;
            if mag < best { best = mag; }
            members += 1;
        }
        if members == 0 || wsum <= 0.0 { continue; }
        let n = (v[0] * v[0] + v[1] * v[1] + v[2] * v[2]).sqrt();
        if n <= 0.0 { continue; }
        let (x, y, z) = (v[0] / n, v[1] / n, v[2] / n);
        out.push(ConCentroid {
            iau: code,
            ra_deg: dc_atan2(y, x).to_degrees().rem_euclid(360.0),
            dec_deg: dc_asin(z.clamp(-1.0, 1.0)).to_degrees(),
            mag: best,
            members,
        });
    }
    out
}

impl FilmTrack {
    /// Build the seek index: for every named star and every constellation, the
    /// film-second at which it is best placed in the frame.
    ///
    /// `steps` is how finely the animation is sampled; `(w, h)` is the frame the
    /// index is computed FOR, because "inside the frame" depends on the aspect
    /// ratio the film is baked at.
    ///
    /// Scoring — what "best placed" means, stated once:
    ///   • it must be above the horizon and bright enough that the film actually
    ///     paints it in that frame, and inside the frame;
    ///   • of those moments, prefer the object HIGH in the sky (clear of the
    ///     horizon murk) and CENTRED in the frame (not clipped at an edge);
    ///   • prefer a dark frame — the same star at midnight beats it at dusk.
    pub fn build_seek_index(&self, w: u32, h: u32, steps: usize) -> Vec<SeekEntry> {
        self.build_seek_index_crop(w, h, w, h, steps)
    }

    /// The seek index for one centred `cw`×`ch` crop of a `w`×`h` render — a
    /// screen shape cut from the square master. "Framed" means inside THAT crop,
    /// and centring is measured against its middle, which is the render's middle.
    pub fn build_seek_index_crop(&self, w: u32, h: u32, cw: u32, ch: u32,
                                 steps: usize) -> Vec<SeekEntry> {
        let stars = crate::star_names::NAMED_STARS;
        let cons = constellation_centroids();
        let ncon = cons.len();
        // The moving bodies share the index with the catalogue, laid out after
        // it: [stars][constellations][Sun, Moon, planets…]. They are scored by
        // exactly the same rule, so "best moment" means the same thing for
        // Jupiter as it does for Vega — the only difference is where the
        // position comes from (the daemon's sample, not a fixed RA/Dec).
        let nbody = 2 + self.names.len();          // Sun + Moon + the planets
        let total = stars.len() + ncon + nbody;
        let body0 = stars.len() + ncon;

        // best (score, t, az, alt, framed) per object, plus its all-film max alt
        let mut best: Vec<(f64, f64, f64, f64, bool)> =
            vec![(f64::MIN, 0.0, 0.0, -90.0, false); total];
        let mut max_alt = vec![-90.0f64; total];

        let half_diag = ((cw as f64).hypot(ch as f64)) * 0.5;
        let (x0, y0) = ((w as f64 - cw as f64) * 0.5, (h as f64 - ch as f64) * 0.5);
        let (x1, y1) = (x0 + cw as f64, y0 + ch as f64);
        let (cx, cy) = (w as f64 * 0.5, h as f64 * 0.5);
        let steps = steps.max(2);

        for k in 0..steps {
            let a = k as f64 / (steps - 1) as f64;
            let t = self.anim_t(a);
            let s = self.shot(t);
            if s.phase != Phase::Anim { continue; }
            let sc = self.scene_at(s.sample);
            let maglim = bsky::scene_star_maglim(&sc, s.sun_off());
            let cb = bsky::camera_basis(s.aim_az, s.aim_alt, s.fov_deg);
            // How dark the frame is, GRADED on the real Sun altitude rather than
            // on the on/off switch. The switch flips at −3°, where the sky is
            // still bright blue; scored on the switch, "seek to Orion" landed at
            // dusk with Orion barely visible. Graded, midnight decisively beats
            // dusk and the seek lands on a frame where the thing is actually there.
            let dark_bonus = 45.0 * ((-sc.sun.alt) / 18.0).clamp(0.0, 1.0);

            // Takes a position that is ALREADY horizontal, because the two kinds
            // of object arrive differently: a catalogue star is a fixed RA/Dec
            // that has to be turned into az/alt for this instant, while the Sun,
            // Moon and planets are handed to us as az/alt by the daemon and have
            // no meaningful fixed RA/Dec at all. Converting first and scoring
            // second lets both walk the identical rule.
            let mut consider = |i: usize, az: f64, alt: f64, mag: f64, is_body: bool| {
                if alt > max_alt[i] { max_alt[i] = alt; }
                // The cinematic film hides everything under the horizon behind
                // solid ground, so a star down there is genuinely not on screen.
                // The planetarium pass draws the full celestial sphere, so the
                // same cull there would throw away exactly the half of the sky
                // that pass exists to show.
                //
                // A BODY IS DIFFERENT, and the difference is not cosmetic. The
                // star field is painted from the catalogue all the way round the
                // sphere, so a star at −38° is genuinely on screen in the night
                // pass. The Sun, Moon and planets are not: their discs are only
                // drawn above the horizon, in either pass. Scoring them by the
                // star rule picked the moment the camera swept nearest to them
                // in space — for this film, the Moon at 35° BELOW the horizon,
                // where nothing whatsoever is painted. Searching "Moon" flew to
                // an empty patch of sky and the card correctly explained why,
                // which is an honest answer to a question nobody asked.
                //
                // Gated on altitude the Moon instead lands at t≈34.7 s, 75° up
                // and plainly on screen. `search_sky` has always used alt > −1.0
                // for exactly this, so the baked index uses the same number
                // rather than a second opinion about the same horizon.
                if is_body {
                    if alt <= -1.0 { return; }
                } else if alt <= 0.5 && !self.night_only { return; }
                if mag > maglim { return; }
                let (x, y) = match bsky::project_dir(bsky::dir_altaz(az, alt), &cb, w, h) {
                    Some(p) => p, None => return };
                if x < x0 || y < y0 || x >= x1 || y >= y1 { return; }
                // 0 dead centre → 1 at the corner.
                let r = ((x - cx).hypot(y - cy)) / half_diag;
                // In the film, height and darkness decide the best moment: a
                // star low in a bright sky is a bad place to send someone.
                //
                // The planetarium pass draws no ground, but the customer's sky
                // still had one. Scored on centring alone it sent 1,410 of 3,187
                // Pai stars and 35 of 88 constellations to a moment BELOW the
                // horizon although each of them rose that day — and the card then
                // told the customer the object was on the far side of the Earth.
                // So a moment when the object was really up outranks every moment
                // when it was not; below-horizon moments only win for an object
                // that never rose.
                //
                // Among the moments it was up, CENTRING decides (weights grid-
                // searched 2026-09-28, `NIGHT_SEEK_WEIGHTS`): an object that
                // lands off-centre can only be brought to the middle by enlarging
                // the film. Preferring height and darkness first pushed the median
                // landing from 66 px to 170 px off centre and asked for more than
                // 2× enlargement 1,094 times. The Sun, Moon and planets add height
                // on top, because centring alone put the Moon 3° above the horizon.
                let film_score = alt + 30.0 * (1.0 - r) + dark_bonus;
                let score = if self.night_only {
                    let (wc, wa, wd) = night_seek_weights();
                    let wa = if is_body { NIGHT_SEEK_BODY_ALT } else { wa };
                    if alt > 0.5 { 1000.0 + wc * (1.0 - r) + wa * alt + wd * dark_bonus }
                    else { 30.0 * (1.0 - r) }
                } else { film_score };
                if score > best[i].0 { best[i] = (score, t, az, alt, true); }
            };

            for (i, st) in stars.iter().enumerate() {
                let (az, alt) = bsky::radec_to_altaz(
                    st.ra as f64, st.dec as f64, sc.lat, sc.lst_deg);
                consider(i, az, alt, st.mag as f64, false);
            }
            for (j, c) in cons.iter().enumerate() {
                let (az, alt) = bsky::radec_to_altaz(
                    c.ra_deg, c.dec_deg, sc.lat, sc.lst_deg);
                consider(stars.len() + j, az, alt, c.mag, false);
            }

            // The bodies. `NEG_INFINITY` as the cull magnitude is not a made-up
            // brightness — it is how they bypass the star magnitude limit, which
            // is the same thing `search_sky` does by never applying `maglim` to
            // them. The Sun and the Moon are never the faint thing in a frame,
            // and a planet is drawn as a globe rather than splatted as a star,
            // so the star cutoff does not decide whether it was painted.
            consider(body0,     sc.sun.az,  sc.sun.alt,  f64::NEG_INFINITY, true);
            consider(body0 + 1, sc.moon.az, sc.moon.alt, f64::NEG_INFINITY, true);
            for (k, pl) in sc.planets.iter().enumerate() {
                consider(body0 + 2 + k, pl.az, pl.alt, f64::NEG_INFINITY, true);
            }
        }

        // An object that never got framed still gets an entry, at the second it
        // stood HIGHEST — that is the honest "closest we can offer".
        let mut fallback_pass = vec![false; total];
        for i in 0..total { if !best[i].4 { fallback_pass[i] = true; } }
        if fallback_pass.iter().any(|b| *b) {
            for k in 0..steps {
                let a = k as f64 / (steps - 1) as f64;
                let t = self.anim_t(a);
                let s = self.shot(t);
                if s.phase != Phase::Anim { continue; }
                let sc = self.scene_at(s.sample);
                let mut consider = |i: usize, az: f64, alt: f64| {
                    if !fallback_pass[i] { return; }
                    if alt > best[i].3 { best[i] = (alt, t, az, alt, false); }
                };
                for (i, st) in stars.iter().enumerate() {
                    let (az, alt) = bsky::radec_to_altaz(
                        st.ra as f64, st.dec as f64, sc.lat, sc.lst_deg);
                    consider(i, az, alt);
                }
                for (j, c) in cons.iter().enumerate() {
                    let (az, alt) = bsky::radec_to_altaz(
                        c.ra_deg, c.dec_deg, sc.lat, sc.lst_deg);
                    consider(stars.len() + j, az, alt);
                }
                consider(body0,     sc.sun.az,  sc.sun.alt);
                consider(body0 + 1, sc.moon.az, sc.moon.alt);
                for (k, pl) in sc.planets.iter().enumerate() {
                    consider(body0 + 2 + k, pl.az, pl.alt);
                }
            }
        }

        let mut out = Vec::with_capacity(total);
        for (i, st) in stars.iter().enumerate() {
            let (_, t, az, alt, framed) = best[i];
            let name = if st.proper.is_empty() { st.bf } else { st.proper };
            if name.is_empty() { continue; }
            out.push(SeekEntry {
                kind: "star",
                key: if st.hip >= 0 { st.hip.to_string() } else { name.to_string() },
                name: name.to_string(), con: st.con.to_string(),
                t_sec: t, az, alt, framed, max_alt: max_alt[i], mag: st.mag as f64,
                ang_size_deg: f64::NAN, illum: f64::NAN,
                phase_angle_deg: f64::NAN, waxing: false,
            });
        }
        for (j, c) in cons.iter().enumerate() {
            let i = stars.len() + j;
            let (_, t, az, alt, framed) = best[i];
            out.push(SeekEntry {
                kind: "con",
                key: c.iau.to_string(),
                name: crate::con_meta::latin(c.iau).unwrap_or(c.iau).to_string(),
                con: c.iau.to_string(),
                t_sec: t, az, alt, framed, max_alt: max_alt[i], mag: c.mag,
                ang_size_deg: f64::NAN, illum: f64::NAN,
                phase_angle_deg: f64::NAN, waxing: false,
            });
        }

        // ── the moving bodies ────────────────────────────────────────────────
        // A body's facts are not constants to be looked up — its disc grows and
        // shrinks and the Moon's phase changes across the film. So each one is
        // read back from the scene at the SECOND IT WAS CHOSEN, which is the
        // instant the customer is going to be looking at. Reading them at any
        // other sample would put a caption on the wrong frame.
        for k in 0..nbody {
            let i = body0 + k;
            let (_, t, az, alt, framed) = best[i];
            let sc = self.scene_at(self.shot(t).sample);
            let (kind, name, mag, ang, illum, phase, waxing) = if k == 0 {
                ("sun", "Sun".to_string(), f64::NAN, sc.sun.ang_size_deg,
                 f64::NAN, f64::NAN, false)
            } else if k == 1 {
                ("moon", "Moon".to_string(), f64::NAN, sc.moon.ang_size_deg,
                 sc.moon.illum_fraction, sc.moon.phase_angle_deg, sc.moon.waxing)
            } else {
                let pl = &sc.planets[k - 2];
                ("planet", pl.name.clone(), pl.mag, pl.ang_size_deg,
                 f64::NAN, f64::NAN, false)
            };
            out.push(SeekEntry {
                kind,
                key: name.clone(),
                name,
                // A body wanders across constellation boundaries and this
                // pipeline holds no boundary polygons, only centroids. Naming
                // the nearest centroid would read as "Jupiter is in Taurus"
                // while being a different claim entirely, so the field is left
                // empty rather than filled with something that looks right.
                con: String::new(),
                t_sec: t, az, alt, framed, max_alt: max_alt[i],
                mag, ang_size_deg: ang, illum, phase_angle_deg: phase, waxing,
            });
        }
        out
    }
}
